package com.example.minimallauncher

import android.annotation.SuppressLint
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** 화면 위에 덮는 레이어(메뉴, 폴더, 검색 등) 공통 */
open class Overlay(val act: MainActivity) : FrameLayout(act) {
    open val dimColor: Int = 0x8C000000.toInt()
    open fun onShown() {}
    open fun onHidden() {}
    open fun onInsetsChanged() {}
    open fun dismiss() { act.closeOverlay(this) }
}

class MenuEntry(
    val label: String,
    val icon: Drawable? = null,
    val destructive: Boolean = false,
    val action: () -> Unit,
)

/** 길게 누르면 나오는 메뉴 (아이콘을 띄우고 아래/위에 메뉴 카드) */
@SuppressLint("ViewConstructor")
class ContextMenuOverlay(
    act: MainActivity,
    private val anchor: RectF,
    preview: Bitmap?,
    groups: List<List<MenuEntry>>,
) : Overlay(act) {
    override val dimColor = 0x73000000

    private val card = LinearLayout(act)

    init {
        setOnClickListener { dismiss() }
        if (preview != null) {
            val iv = ImageView(act)
            iv.setImageBitmap(preview)
            iv.scaleType = ImageView.ScaleType.FIT_XY
            addView(iv, LayoutParams(anchor.width().toInt(), anchor.height().toInt()).apply {
                leftMargin = anchor.left.toInt(); topMargin = anchor.top.toInt()
            })
            iv.scaleX = 1.06f; iv.scaleY = 1.06f
        }
        card.orientation = LinearLayout.VERTICAL
        card.background = Glass.panel(0xF2262628.toInt(), act.dp(24).toFloat(), 0x1FFFFFFF, 1)
        card.clipToOutline = true
        card.elevation = act.dp(12).toFloat()
        groups.filter { it.isNotEmpty() }.forEachIndexed { gi, group ->
            if (gi > 0) {
                card.addView(View(act).apply { setBackgroundColor(0x99000000.toInt()) },
                    LinearLayout.LayoutParams(-1, act.dp(7)))
            }
            group.forEachIndexed { i, e ->
                if (i > 0) card.addView(View(act).apply { setBackgroundColor(0x33FFFFFF) },
                    LinearLayout.LayoutParams(-1, 1))
                card.addView(row(e), LinearLayout.LayoutParams(-1, act.dp(48)))
            }
        }
        val w = act.dp(254)
        card.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        val h = card.measuredHeight
        val sw = act.screenW; val sh = act.screenH
        val margin = act.dp(14)
        val below = anchor.bottom + act.dp(14) + h < sh - act.insetBottom - margin
        val top = if (below) anchor.bottom + act.dp(14) else max(act.insetTop + margin.toFloat(), anchor.top - act.dp(14) - h)
        val left = if (anchor.centerX() < sw / 2f) anchor.left - act.dp(4) else anchor.right + act.dp(4) - w
        val lp = LayoutParams(w, LayoutParams.WRAP_CONTENT).apply {
            leftMargin = left.toInt().coerceIn(margin, sw - w - margin)
            topMargin = top.toInt()
        }
        addView(card, lp)
        card.pivotX = if (anchor.centerX() < sw / 2f) 0f else w.toFloat()
        card.pivotY = if (below) 0f else h.toFloat()
        card.scaleX = 0.7f; card.scaleY = 0.7f; card.alpha = 0f
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(200).start()
    }

    private fun row(e: MenuEntry): View {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(act.dp(18), 0, act.dp(16), 0)
        r.background = act.pressedBg()
        val tv = TextView(act)
        tv.text = e.label
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16.5f)
        tv.setTextColor(if (e.destructive) 0xFFFF453A.toInt() else Color.WHITE)
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        r.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        if (e.icon != null) {
            val iv = ImageView(act)
            iv.setImageDrawable(e.icon)
            r.addView(iv, LinearLayout.LayoutParams(act.dp(22), act.dp(22)))
        }
        r.setOnClickListener {
            act.closeOverlay(this, animate = false)
            e.action()
        }
        return r
    }
}

class AlertButton(val label: String, val style: Int, val action: () -> Unit) {
    companion object { const val NORMAL = 0; const val CANCEL = 1; const val DESTRUCTIVE = 2 }
}

/** iOS 스타일 알림창 (버튼이 3개 이상이면 세로로 쌓임) */
@SuppressLint("ViewConstructor")
class AlertOverlay(act: MainActivity, title: String, message: String?, buttons: List<AlertButton>) : Overlay(act) {
    override val dimColor = 0x66000000

    init {
        isClickable = true
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.background = Glass.panel(0xF2252527.toInt(), act.dp(20).toFloat(), 0x1FFFFFFF, 1)
        card.clipToOutline = true
        val tv = TextView(act)
        tv.text = title
        tv.setTextColor(Color.WHITE)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        tv.setPadding(act.dp(16), act.dp(20), act.dp(16), if (message == null) act.dp(20) else act.dp(4))
        card.addView(tv)
        if (message != null) {
            val mv = TextView(act)
            mv.text = message
            mv.setTextColor(0xFFEBEBF5.toInt())
            mv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            mv.gravity = Gravity.CENTER
            mv.setPadding(act.dp(16), 0, act.dp(16), act.dp(20))
            card.addView(mv)
        }
        val horizontal = buttons.size == 2
        val row = LinearLayout(act)
        row.orientation = if (horizontal) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        buttons.forEachIndexed { i, b ->
            if (!horizontal || i > 0) {
                row.addView(View(act).apply { setBackgroundColor(0x40FFFFFF) },
                    if (horizontal) LinearLayout.LayoutParams(1, -1) else LinearLayout.LayoutParams(-1, 1))
            }
            val bt = TextView(act)
            bt.text = b.label
            bt.gravity = Gravity.CENTER
            bt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            bt.setTextColor(if (b.style == AlertButton.DESTRUCTIVE) 0xFFFF453A.toInt() else 0xFF0A84FF.toInt())
            if (b.style == AlertButton.CANCEL) bt.typeface = Typeface.DEFAULT_BOLD
            bt.background = act.pressedBg()
            bt.setOnClickListener { act.closeOverlay(this, animate = false); b.action() }
            row.addView(bt, if (horizontal) LinearLayout.LayoutParams(0, act.dp(46), 1f) else LinearLayout.LayoutParams(-1, act.dp(46)))
        }
        if (horizontal) {
            card.addView(View(act).apply { setBackgroundColor(0x40FFFFFF) }, LinearLayout.LayoutParams(-1, 1))
        }
        card.addView(row)
        addView(card, LayoutParams(act.dp(280), LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        card.scaleX = 1.15f; card.scaleY = 1.15f; card.alpha = 0f
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()
    }
}

/** 폴더 열기 (홈 화면 폴더: 3×3 페이지, 앱 보관함 카테고리: 세로 스크롤) */
@SuppressLint("ViewConstructor")
class FolderOverlay(
    act: MainActivity,
    val folder: HomeItem.Folder?,
    titleText: String,
    private val apps: List<AppInfo>,
    private val from: RectF?,
    editTitle: Boolean,
) : Overlay(act) {
    override val dimColor = 0x8C000000.toInt()
    val panel = FrameLayout(act)
    private val title = EditText(act)
    val pager = PagedView(act)
    private val dots = SearchPill(act)
    val icons = ArrayList<IconView>()
    private val pageGrids = ArrayList<GridPage>()
    private val byKey = HashMap<String, IconView>()

    init {
        setOnClickListener { dismiss() }
        val sw = act.screenW
        val m = act.metrics
        val panelW = min((sw * 0.84f).toInt(), (m.unit * 0.84f).toInt() + (if (m.wide) m.unit * 0.1f else 0f).toInt())
        val cell = panelW / 3
        val rowsPerPage = 3
        val cellH = (cell * 1.08f).toInt()
        val panelH: Int
        val scrollMode = folder == null
        if (scrollMode) {
            val rows = ceil(apps.size / 3.0).toInt().coerceAtLeast(1)
            val maxH = (act.screenH * 0.62f).toInt()
            panelH = min(rows * cellH + act.dp(24), maxH)
            val sv = ScrollView(act)
            sv.isVerticalScrollBarEnabled = false
            val grid = GridPage(act)
            grid.cols = 3; grid.rows = rows; grid.cellW = cell; grid.cellH = cellH; grid.padTop = act.dp(12)
            apps.forEach { grid.addView(icon(it)) }
            sv.addView(grid, ViewGroup.LayoutParams(panelW, rows * cellH + act.dp(24)))
            panel.addView(sv, LayoutParams(-1, -1))
        } else {
            panelH = rowsPerPage * cellH + act.dp(24)
            apps.chunked(9).ifEmpty { listOf(emptyList()) }.forEach { chunk ->
                val g = GridPage(act)
                g.cols = 3; g.rows = 3; g.cellW = cell; g.cellH = cellH; g.padTop = act.dp(12)
                chunk.forEach { g.addView(icon(it)) }
                pager.addView(g)
                pageGrids.add(g)
            }
            panel.addView(pager, LayoutParams(-1, -1))
        }
        panel.background = Glass.panel(0x59505055, act.dp(36).toFloat(), 0x33FFFFFF, 2)
        panel.clipToOutline = true
        panel.isClickable = true
        val top = (act.screenH - panelH) / 2 - act.dp(10)
        addView(panel, LayoutParams(panelW, panelH).apply {
            leftMargin = (sw - panelW) / 2; topMargin = top
        })

        title.setText(titleText)
        title.setTextColor(Color.WHITE)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
        title.typeface = Typeface.DEFAULT_BOLD
        title.background = null
        title.isSingleLine = true
        title.imeOptions = EditorInfo.IME_ACTION_DONE
        title.setPadding(0, 0, 0, 0)
        title.isEnabled = folder != null && (editTitle || act.editMode)
        title.isFocusableInTouchMode = title.isEnabled
        title.setOnEditorActionListener { _, _, _ -> act.hideKeyboard(title); title.clearFocus(); true }
        addView(title, LayoutParams(panelW, LayoutParams.WRAP_CONTENT).apply {
            leftMargin = (sw - panelW) / 2 + act.dp(6); topMargin = top - act.dp(64)
        })

        if (!scrollMode && pager.pageCount > 1) {
            dots.unit = act.metrics.unit
            dots.pageCount = pager.pageCount
            dots.showDots = true
            dots.background = null
            pager.onScroll = { dots.current = it }
            addView(dots, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL).apply {
                topMargin = top + panelH + act.dp(12)
            })
        }
        if (editTitle) {
            title.post { title.requestFocus(); title.selectAll(); act.showKeyboard(title) }
        }
        if (from != null) {
            panel.pivotX = from.centerX() - (sw - panelW) / 2f
            panel.pivotY = from.centerY() - top
            panel.scaleX = from.width() / panelW; panel.scaleY = from.height() / panelH
            panel.alpha = 0.4f
            panel.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(260).start()
        }
    }

    private fun icon(a: AppInfo): IconView {
        val v = act.makeIcon(a, if (folder == null) MainActivity.Src.Library else MainActivity.Src.InFolder(folder))
        icons.add(v)
        byKey[a.key] = v
        if (act.editMode && folder != null) { v.showMinus = a.removable; v.post { v.setJiggle(true) } }
        return v
    }

    fun currentTitle(): String = title.text.toString().trim()

    fun iconFor(key: String): IconView? = byKey[key]

    /** 폴더 안 순서를 바꾼 뒤 다시 배치 */
    fun rebind() {
        val f = folder ?: return
        val keys = f.apps.filter { byKey.containsKey(it) }
        pageGrids.forEachIndexed { pi, g ->
            g.animateNext = true
            g.removeAllViews()
            keys.drop(pi * 9).take(9).forEach { k -> byKey[k]?.let { v -> (v.parent as? ViewGroup)?.removeView(v); g.addView(v) } }
        }
    }

    /** 폴더 안 좌표(루트 기준) → 폴더 앱 순서 */
    fun indexAt(x: Float, y: Float): Int {
        val g = pageGrids.getOrNull(pager.page) ?: return -1
        val r = act.rectOf(g)
        return pager.page * 9 + g.cellAt(x - r.left, y - r.top)
    }

    override fun onHidden() {
        act.hideKeyboard(title)
        if (folder != null) {
            val t = currentTitle()
            if (t.isNotEmpty() && t != folder.name) { folder.name = t; act.saveAndRefresh() }
        }
    }
}

/** 홈에서 아래로 쓸거나 '검색'을 누르면 나오는 검색 화면 */
@SuppressLint("ViewConstructor")
class SpotlightOverlay(act: MainActivity) : Overlay(act) {
    override val dimColor = 0xE0101012.toInt()
    private val scroll = ScrollView(act)
    private val list = LinearLayout(act)
    private val bar = LinearLayout(act)
    private val field = EditText(act)
    private val clear = TextView(act)

    init {
        scroll.isVerticalScrollBarEnabled = false
        list.orientation = LinearLayout.VERTICAL
        list.setOnClickListener { dismiss() }
        scroll.addView(list, ViewGroup.LayoutParams(-1, -2))
        scroll.isFillViewport = true
        scroll.setOnScrollChangeListener { _, _, y, _, oy -> if (y - oy > act.dp(6)) act.hideKeyboard(field) }
        addView(scroll, LayoutParams(-1, -1))

        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = Glass.panel(0xCC3A3A3C.toInt(), act.dp(26).toFloat(), 0x26FFFFFF, 1)
        bar.setPadding(act.dp(14), 0, act.dp(10), 0)
        bar.addView(GlyphView(act, GlyphView.SEARCH, 0xB3FFFFFF.toInt()), LinearLayout.LayoutParams(act.dp(20), act.dp(20)))
        field.hint = "검색"
        field.setHintTextColor(0x99FFFFFF.toInt())
        field.setTextColor(Color.WHITE)
        field.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        field.background = null
        field.isSingleLine = true
        field.inputType = InputType.TYPE_CLASS_TEXT
        field.imeOptions = EditorInfo.IME_ACTION_SEARCH
        field.setPadding(act.dp(8), 0, act.dp(8), 0)
        bar.addView(field, LinearLayout.LayoutParams(0, -1, 1f))
        clear.text = "✕"
        clear.setTextColor(0xB3FFFFFF.toInt())
        clear.gravity = Gravity.CENTER
        clear.visibility = View.GONE
        clear.setOnClickListener { field.setText("") }
        bar.addView(clear, LinearLayout.LayoutParams(act.dp(32), act.dp(32)))
        addView(bar, LayoutParams(-1, act.dp(52), Gravity.BOTTOM))

        field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                clear.visibility = if (s.isNullOrEmpty()) View.GONE else View.VISIBLE
                render(s?.toString() ?: "")
            }
        })
        field.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_SEARCH || ev?.keyCode == KeyEvent.KEYCODE_ENTER) {
                val q = field.text.toString().trim()
                val hit = act.searchApps(q).firstOrNull()
                if (hit != null) act.launch(hit, null) else if (q.isNotEmpty()) act.webSearch(q)
                true
            } else false
        }
        render("")
        onInsetsChanged()
        alpha = 0f
        animate().alpha(1f).setDuration(180).start()
    }

    override fun onShown() {
        field.requestFocus()
        field.post { act.showKeyboard(field) }
    }

    override fun onHidden() { act.hideKeyboard(field) }

    override fun onInsetsChanged() {
        val m = act.dp(16)
        (bar.layoutParams as LayoutParams).apply {
            leftMargin = m; rightMargin = m
            bottomMargin = max(act.insetBottom, act.imeBottom) + act.dp(10)
        }
        bar.requestLayout()
        list.setPadding(m, act.insetTop + act.dp(24), m, max(act.insetBottom, act.imeBottom) + act.dp(80))
    }

    private fun header(t: String) {
        val tv = TextView(act)
        tv.text = t
        tv.setTextColor(0xB3FFFFFF.toInt())
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(act.dp(4), act.dp(18), 0, act.dp(8))
        list.addView(tv)
    }

    private fun appGrid(apps: List<AppInfo>) {
        val m = act.metrics
        val cols = if (m.wide) 6 else 4
        val rows = ceil(apps.size / cols.toDouble()).toInt()
        val g = GridPage(act)
        g.cols = cols; g.rows = rows
        g.cellW = (act.screenW - act.dp(32)) / cols
        g.cellH = (m.cellH * 0.95f).toInt()
        apps.forEach { g.addView(act.makeIcon(it, MainActivity.Src.Search)) }
        list.addView(g, LinearLayout.LayoutParams(-1, rows * g.cellH))
    }

    private fun render(raw: String) {
        list.removeAllViews()
        val q = raw.trim()
        if (q.isEmpty()) {
            header("제안")
            appGrid(act.suggestions(if (act.metrics.wide) 12 else 8))
            return
        }
        val hits = act.searchApps(q)
        if (hits.isNotEmpty()) {
            header("가장 연관성 높은 항목")
            list.addView(topHit(hits[0]))
            if (hits.size > 1) {
                header("앱")
                appGrid(hits.drop(1).take(12))
            }
        }
        header("제안")
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = Glass.panel(0x33FFFFFF, act.dp(16).toFloat(), 0, 0)
        row.setPadding(act.dp(14), act.dp(12), act.dp(14), act.dp(12))
        row.addView(GlyphView(act, GlyphView.SEARCH, Color.WHITE), LinearLayout.LayoutParams(act.dp(22), act.dp(22)))
        val tv = TextView(act)
        tv.text = "웹에서 \"$q\" 검색"
        tv.setTextColor(Color.WHITE)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        tv.setPadding(act.dp(12), 0, 0, 0)
        row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        row.setOnClickListener { act.webSearch(q) }
        list.addView(row, LinearLayout.LayoutParams(-1, -2))
    }

    /** 가장 연관성 높은 앱 + 그 앱의 바로가기 버튼 (스크린샷의 'Claude에게 묻기' 같은 것) */
    private fun topHit(app: AppInfo): View {
        val card = LinearLayout(act)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = Glass.panel(0x33FFFFFF, act.dp(26).toFloat(), 0, 0)
        card.setPadding(act.dp(8), act.dp(12), act.dp(8), act.dp(12))
        val iconCell = act.metrics.cellW
        val iv = act.makeIcon(app, MainActivity.Src.Search)
        card.addView(iv, LinearLayout.LayoutParams(iconCell, act.metrics.cellH))
        act.shortcutsFor(app).take(3).forEach { si ->
            val col = LinearLayout(act)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val circle = FrameLayout(act)
            circle.background = Glass.panel(0x40FFFFFF, act.dp(28).toFloat(), 0, 0)
            val sic = ImageView(act)
            sic.setImageDrawable(act.shortcutIcon(si))
            circle.addView(sic, LayoutParams(act.dp(28), act.dp(28), Gravity.CENTER))
            col.addView(circle, LinearLayout.LayoutParams(act.dp(56), act.dp(56)))
            val t = TextView(act)
            t.text = si.shortLabel
            t.setTextColor(Color.WHITE)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            t.gravity = Gravity.CENTER
            t.maxLines = 2
            t.ellipsize = TextUtils.TruncateAt.END
            t.setPadding(0, act.dp(6), 0, 0)
            col.addView(t, LinearLayout.LayoutParams(-1, -2))
            col.setOnClickListener { act.startShortcut(si); dismiss() }
            card.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
        return card
    }
}

/** 앱 보관함 검색: 가나다/ABC 목록 + 오른쪽 색인 */
@SuppressLint("ViewConstructor")
class LibrarySearchOverlay(act: MainActivity, private val withKeyboard: Boolean) : Overlay(act) {
    override val dimColor = 0xF0101012.toInt()
    private val field = EditText(act)
    private val scroll = ScrollView(act)
    private val list = LinearLayout(act)
    private val index = LinearLayout(act)
    private val sectionViews = HashMap<String, View>()

    init {
        isClickable = true
        val top = LinearLayout(act)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val pill = LinearLayout(act)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.background = Glass.panel(0xCC3A3A3C.toInt(), act.dp(22).toFloat(), 0x26FFFFFF, 1)
        pill.setPadding(act.dp(12), 0, act.dp(12), 0)
        pill.addView(GlyphView(act, GlyphView.SEARCH, 0xB3FFFFFF.toInt()), LinearLayout.LayoutParams(act.dp(18), act.dp(18)))
        field.hint = "앱 보관함"
        field.setHintTextColor(0x99FFFFFF.toInt())
        field.setTextColor(Color.WHITE)
        field.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        field.background = null
        field.isSingleLine = true
        field.setPadding(act.dp(8), 0, 0, 0)
        pill.addView(field, LinearLayout.LayoutParams(0, -1, 1f))
        top.addView(pill, LinearLayout.LayoutParams(0, act.dp(44), 1f))
        val cancel = TextView(act)
        cancel.text = "취소"
        cancel.setTextColor(0xFF0A84FF.toInt())
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        cancel.setPadding(act.dp(14), act.dp(8), act.dp(4), act.dp(8))
        cancel.setOnClickListener { dismiss() }
        top.addView(cancel)
        addView(top, LayoutParams(-1, -2).apply {
            topMargin = act.insetTop + act.dp(10); leftMargin = act.dp(16); rightMargin = act.dp(12)
        })

        list.orientation = LinearLayout.VERTICAL
        scroll.addView(list, ViewGroup.LayoutParams(-1, -2))
        scroll.isVerticalScrollBarEnabled = false
        scroll.setOnScrollChangeListener { _, _, y, _, oy -> if (y != oy) act.hideKeyboard(field) }
        addView(scroll, LayoutParams(-1, -1).apply {
            topMargin = act.insetTop + act.dp(64); leftMargin = act.dp(16); rightMargin = act.dp(28)
        })

        index.orientation = LinearLayout.VERTICAL
        index.gravity = Gravity.CENTER
        addView(index, LayoutParams(act.dp(24), -1, Gravity.END).apply {
            topMargin = act.insetTop + act.dp(70); bottomMargin = act.insetBottom + act.dp(16)
        })
        index.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                val n = index.childCount
                if (n > 0) {
                    val i = (e.y / v.height * n).toInt().coerceIn(0, n - 1)
                    val key = (index.getChildAt(i) as TextView).text.toString()
                    sectionViews[key]?.let { scroll.scrollTo(0, it.top) }
                }
            }
            true
        }

        field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { render(s?.toString() ?: "") }
        })
        render("")
        alpha = 0f
        animate().alpha(1f).setDuration(180).start()
    }

    override fun onShown() {
        if (withKeyboard) { field.requestFocus(); field.post { act.showKeyboard(field) } }
    }

    override fun onHidden() { act.hideKeyboard(field) }

    private fun render(q: String) {
        list.removeAllViews(); index.removeAllViews(); sectionViews.clear()
        val apps = if (q.isBlank()) act.allApps() else act.searchApps(q.trim())
        val groups = apps.groupBy { Hangul.section(it.label) }.toSortedMap(compareBy { Hangul.order(it) })
        for ((sec, items) in groups) {
            val h = TextView(act)
            h.text = sec
            h.setTextColor(0x99FFFFFF.toInt())
            h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            h.typeface = Typeface.DEFAULT_BOLD
            h.setPadding(act.dp(4), act.dp(14), 0, act.dp(4))
            list.addView(h)
            sectionViews[sec] = h
            items.forEach { list.addView(row(it)) }
            if (q.isBlank()) {
                val t = TextView(act)
                t.text = sec
                t.setTextColor(0xFF0A84FF.toInt())
                t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                t.gravity = Gravity.CENTER
                index.addView(t, LinearLayout.LayoutParams(-1, 0, 1f))
            }
        }
    }

    private fun row(a: AppInfo): View {
        val r = LinearLayout(act)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(act.dp(4), act.dp(6), act.dp(4), act.dp(6))
        r.background = act.pressedBg()
        val iv = ImageView(act)
        iv.setImageBitmap(a.icon)
        r.addView(iv, LinearLayout.LayoutParams(act.dp(42), act.dp(42)))
        val tv = TextView(act)
        tv.text = a.label
        tv.setTextColor(Color.WHITE)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        tv.setPadding(act.dp(14), 0, 0, 0)
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        r.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        r.setOnClickListener { act.launch(a, iv) }
        r.setOnLongClickListener {
            r.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
            act.showAppMenu(a, null, act.rectOf(iv), a.icon, MainActivity.Src.Library)
            true
        }
        return r
    }
}

/** 위젯 추가 목록 (내장 위젯 + 안드로이드 위젯) */
@SuppressLint("ViewConstructor")
class WidgetPickerOverlay(act: MainActivity, providers: List<AppWidgetProviderInfo>) : Overlay(act) {
    override val dimColor = 0x99000000.toInt()

    init {
        setOnClickListener { dismiss() }
        val sheet = LinearLayout(act)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.background = Glass.panel(0xF71C1C1E.toInt(), act.dp(28).toFloat(), 0x1FFFFFFF, 1)
        sheet.isClickable = true
        sheet.setPadding(act.dp(18), act.dp(18), act.dp(18), act.insetBottom + act.dp(12))
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(act)
        t.text = "위젯 추가"
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        t.typeface = Typeface.DEFAULT_BOLD
        head.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        val x = TextView(act)
        x.text = "닫기"
        x.setTextColor(0xFF0A84FF.toInt())
        x.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        x.setOnClickListener { dismiss() }
        head.addView(x)
        sheet.addView(head)

        val sv = ScrollView(act)
        val l = LinearLayout(act)
        l.orientation = LinearLayout.VERTICAL
        sv.addView(l)
        fun section(name: String) {
            val h = TextView(act)
            h.text = name
            h.setTextColor(0x99FFFFFF.toInt())
            h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            h.setPadding(0, act.dp(16), 0, act.dp(6))
            l.addView(h)
        }
        fun item(label: String, sub: String, icon: Drawable?, onPick: () -> Unit) {
            val r = LinearLayout(act)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(act.dp(6), act.dp(10), act.dp(6), act.dp(10))
            r.background = act.pressedBg()
            val iv = ImageView(act)
            if (icon != null) iv.setImageDrawable(icon)
            r.addView(iv, LinearLayout.LayoutParams(act.dp(36), act.dp(36)))
            val col = LinearLayout(act)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(act.dp(12), 0, 0, 0)
            val a = TextView(act); a.text = label; a.setTextColor(Color.WHITE); a.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            val b = TextView(act); b.text = sub; b.setTextColor(0x99FFFFFF.toInt()); b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            col.addView(a); col.addView(b)
            r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            r.setOnClickListener { act.closeOverlay(this, animate = false); onPick() }
            l.addView(r)
        }
        section("기본 위젯")
        item("사진", "중간", null) { act.addWidget("builtin:photo") }
        item("캘린더", "작게", null) { act.addWidget("builtin:calendar") }
        item("시계", "작게", null) { act.addWidget("builtin:clock") }
        item("배터리", "작게", null) { act.addWidget("builtin:battery") }
        if (providers.isNotEmpty()) section("앱 위젯")
        val pm = act.packageManager
        val density = act.resources.displayMetrics.densityDpi
        providers.sortedBy { it.loadLabel(pm) }.forEach { p ->
            val icon = try { p.loadIcon(act, density) } catch (e: Exception) { null }
            val appLabel = try { pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString() } catch (e: Exception) { p.provider.packageName }
            item(p.loadLabel(pm) ?: appLabel, appLabel, icon) { act.pickAppWidget(p) }
        }
        sheet.addView(sv, LinearLayout.LayoutParams(-1, (act.screenH * 0.6f).toInt()))
        addView(sheet, LayoutParams(-1, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        sheet.translationY = act.screenH * 0.3f
        sheet.animate().translationY(0f).setDuration(240).start()
    }
}

/** 작은 그림 아이콘 (돋보기 등) */
@SuppressLint("ViewConstructor")
class GlyphView(context: Context, private val kind: Int, private val color: Int) : View(context) {
    override fun onDraw(canvas: Canvas) {
        when (kind) {
            SEARCH -> Glyphs.search(canvas, width / 2f, height / 2f, min(width, height).toFloat(), color)
            PLUS -> {
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; strokeWidth = width * 0.12f; strokeCap = Paint.Cap.ROUND }
                canvas.drawLine(width * 0.2f, height / 2f, width * 0.8f, height / 2f, p)
                canvas.drawLine(width / 2f, height * 0.2f, width / 2f, height * 0.8f, p)
            }
        }
    }

    companion object { const val SEARCH = 0; const val PLUS = 1 }
}
