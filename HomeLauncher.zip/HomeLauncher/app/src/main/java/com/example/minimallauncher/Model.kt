package com.example.minimallauncher

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Process
import android.os.UserHandle
import android.os.UserManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.Collator
import java.util.Locale

/** 설치된 앱 하나 (사용자 프로필별로 구분) */
class AppInfo(
    val key: String,
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val user: UserHandle,
    val icon: Bitmap,
    val category: String,
    val installTime: Long,
    val updateTime: Long,
    val removable: Boolean,
    val work: Boolean,
)

/** 홈 화면/독에 놓이는 항목. 동일성은 객체 자체로 판단한다. */
sealed class HomeItem {
    class App(val key: String) : HomeItem()
    class Folder(var name: String, val apps: MutableList<String>) : HomeItem()
}

object Categories {
    // 앱 보관함 카테고리 이름 (iOS 한국어 표기를 따름. 일부는 확인 못 함)
    const val SOCIAL = "소셜 미디어"
    const val ENTERTAINMENT = "엔터테인먼트"
    const val GAMES = "게임"
    const val PRODUCTIVITY = "생산성 및 금융"
    const val UTILITIES = "유틸리티"
    const val INFO = "정보 및 도서"
    const val TRAVEL = "여행"
    const val SHOPPING = "쇼핑 및 음식"
    const val CREATIVITY = "크리에이티비티"
    const val HEALTH = "건강 및 피트니스"
    const val EDUCATION = "교육"
    const val WORK = "기업용 앱"
    const val OTHER = "기타"

    // 안드로이드에는 앱스토어 카테고리가 없어서, 앱이 선언한 카테고리가 없을 때만 쓰는 패키지 이름 규칙
    private val rules: List<Pair<String, List<String>>> = listOf(
        PRODUCTIVITY to listOf(
            "kbstar", "kbcard", "shinhan", "wooribank", "woori", "kakaobank", "viva.republica", "toss",
            "hanabank", "hana", "ibk", "nhbank", "nonghyup", "kftc", "lottecard", "samsungcard", "hyundaicard",
            "upbit", "dunamu", "bithumb", "kiwoom", "miraeasset", "sec.android.app.myfiles", "polaris",
            "microsoft.office", "google.android.apps.docs", "notion", "slack", "hometax", "nts.", "kakaowork",
            "authenticator", "google.android.keep", "evernote", "dropbox", "naver.nmybox", "samsung.android.app.notes",
        ),
        SOCIAL to listOf(
            "kakao.talk", "nhn.android.band", "instagram", "facebook", "messenger", "orca", "twitter", "discord",
            "line.android", "telegram", "whatsapp", "everytime", "blind", "daangn", "kakao.story", "threads",
            "android.dialer", "contacts", "messaging", "mms", "naver.prism",
        ),
        ENTERTAINMENT to listOf(
            "youtube", "netflix", "disney", "tving", "wavve", "coupangplay", "watcha", "melon", "genie", "spotify",
            "bugs", "flo", "laftel", "chzzk", "afreeca", "soop", "twitch", "music", "video", "mxtech",
        ),
        INFO to listOf(
            "webtoon", "kakao.page", "ridi", "lezhin", "novelpia", "munpia", "series", "naver.news", "kindle",
            "millie", "yes24", "kyobo", "papago", "dictionary", "wikipedia", "weather",
        ),
        TRAVEL to listOf(
            "korail", "srt", "yanolja", "goodchoice", "yeogi", "airbnb", "kakao.taxi", "kakaot", "socar", "tmoney",
            "jejuair", "koreanair", "flyasiana", "kakaomap", "nmap", "navermap", "google.android.apps.maps",
            "tmap", "subway", "kakaometro", "agoda", "booking", "expedia", "skyscanner", "myrealtrip",
        ),
        SHOPPING to listOf(
            "coupang", "baemin", "woowahan", "yogiyo", "elevenst", "11st", "gmarket", "auction", "kurly",
            "musinsa", "kream", "bucketplace", "ohou", "zigzag", "ably", "temu", "aliexpress", "ssg", "lotteon",
            "zara", "oliveyoung", "starbucks", "mcdonalds",
        ),
        HEALTH to listOf("health", "fitness", "nhis", "doctornow", "goodoc", "strava", "nike"),
        CREATIVITY to listOf("camera", "gallery", "photo", "adobe", "snow", "b612", "vsco", "capcut", "foodie", "canva"),
        EDUCATION to listOf("classting", "duolingo", "speak", "edu", "cake", "elsa", "multicampus"),
    )

    fun of(ai: ApplicationInfo, pkg: String, work: Boolean): String {
        if (work) return WORK
        when (ai.category) {
            ApplicationInfo.CATEGORY_GAME -> return GAMES
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> return ENTERTAINMENT
            ApplicationInfo.CATEGORY_IMAGE -> return CREATIVITY
            ApplicationInfo.CATEGORY_SOCIAL -> return SOCIAL
            ApplicationInfo.CATEGORY_NEWS -> return INFO
            ApplicationInfo.CATEGORY_MAPS -> return TRAVEL
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> return PRODUCTIVITY
            ApplicationInfo.CATEGORY_ACCESSIBILITY -> return UTILITIES
        }
        if (ai.flags and ApplicationInfo.FLAG_IS_GAME != 0) return GAMES
        val p = pkg.lowercase(Locale.ROOT)
        for ((cat, keys) in rules) {
            if (keys.any { p.contains(it) }) return cat
        }
        if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0) return UTILITIES
        return OTHER
    }
}

object AppRepository {
    fun keyOf(cn: ComponentName, serial: Long): String = cn.flattenToShortString() + "#" + serial

    fun load(ctx: Context, iconPx: Int): List<AppInfo> {
        val la = ctx.getSystemService(LauncherApps::class.java)
        val um = ctx.getSystemService(UserManager::class.java)
        val pm = ctx.packageManager
        val me = Process.myUserHandle()
        val out = ArrayList<AppInfo>()
        val profiles = try { la.profiles } catch (e: Exception) { listOf(me) }
        for (user in profiles) {
            val serial = um.getSerialNumberForUser(user)
            val work = user != me
            val list = try { la.getActivityList(null, user) } catch (e: Exception) { emptyList() }
            for (lai in list) {
                val cn = lai.componentName
                if (cn.packageName == ctx.packageName) continue
                val ai = lai.applicationInfo
                var icon = try {
                    IconFactory.appIcon(lai.getIcon(0), iconPx)
                } catch (e: Exception) {
                    IconFactory.blank(iconPx)
                }
                if (work) {
                    try {
                        val badged = pm.getUserBadgedIcon(BitmapDrawable(ctx.resources, icon), user)
                        icon = IconFactory.drawableToBitmap(badged, iconPx)
                    } catch (e: Exception) { }
                }
                var update = lai.firstInstallTime
                try {
                    if (!work) update = pm.getPackageInfo(cn.packageName, 0).lastUpdateTime
                } catch (e: Exception) { }
                val system = ai.flags and ApplicationInfo.FLAG_SYSTEM != 0
                out.add(
                    AppInfo(
                        key = keyOf(cn, serial),
                        label = lai.label?.toString()?.trim().orEmpty().ifEmpty { cn.packageName },
                        pkg = cn.packageName,
                        component = cn,
                        user = user,
                        icon = icon,
                        category = Categories.of(ai, cn.packageName, work),
                        installTime = lai.firstInstallTime,
                        updateTime = update,
                        removable = !system,
                        work = work,
                    )
                )
            }
        }
        val col = Collator.getInstance(Locale.KOREAN)
        out.sortWith { a, b -> col.compare(a.label, b.label) }
        return out
    }
}

/** 홈 화면 배치 저장소 */
class LayoutStore(private val prefs: SharedPreferences) {
    val pages = ArrayList<MutableList<HomeItem>>()
    val dock = ArrayList<HomeItem>()
    val widgets = ArrayList<String>()
    val known = HashSet<String>()

    val hasLayout: Boolean get() = prefs.contains("layout")

    fun load() {
        pages.clear(); dock.clear(); known.clear(); widgets.clear()
        val s = prefs.getString("layout", null)
        if (s != null) {
            try {
                val o = JSONObject(s)
                val pa = o.optJSONArray("pages") ?: JSONArray()
                for (i in 0 until pa.length()) {
                    val arr = pa.getJSONArray(i)
                    pages.add(readItems(arr))
                }
                dock.addAll(readItems(o.optJSONArray("dock") ?: JSONArray()))
                val k = o.optJSONArray("known") ?: JSONArray()
                for (i in 0 until k.length()) known.add(k.getString(i))
            } catch (e: Exception) {
                pages.clear(); dock.clear()
            }
        }
        val w = prefs.getString("widgets", null)
        if (w != null) {
            try {
                val a = JSONArray(w)
                for (i in 0 until a.length()) widgets.add(a.getString(i))
            } catch (e: Exception) { }
        } else {
            widgets.addAll(listOf("builtin:photo", "builtin:calendar", "builtin:clock", "builtin:battery"))
        }
    }

    private fun readItems(arr: JSONArray): MutableList<HomeItem> {
        val out = ArrayList<HomeItem>()
        for (i in 0 until arr.length()) {
            val it = arr.getJSONObject(i)
            if (it.has("f")) {
                val apps = ArrayList<String>()
                val a = it.getJSONArray("apps")
                for (j in 0 until a.length()) apps.add(a.getString(j))
                out.add(HomeItem.Folder(it.getString("f"), apps))
            } else {
                out.add(HomeItem.App(it.getString("a")))
            }
        }
        return out
    }

    private fun writeItems(items: List<HomeItem>): JSONArray {
        val arr = JSONArray()
        for (item in items) {
            when (item) {
                is HomeItem.App -> arr.put(JSONObject().put("a", item.key))
                is HomeItem.Folder -> arr.put(JSONObject().put("f", item.name).put("apps", JSONArray(item.apps)))
            }
        }
        return arr
    }

    fun save() {
        val o = JSONObject()
        val pa = JSONArray()
        pages.forEach { pa.put(writeItems(it)) }
        o.put("pages", pa)
        o.put("dock", writeItems(dock))
        o.put("known", JSONArray(known.toList()))
        prefs.edit()
            .putString("layout", o.toString())
            .putString("widgets", JSONArray(widgets).toString())
            .apply()
    }

    /** 홈 화면(폴더 포함)과 독에 있는 모든 앱 키 */
    fun placedKeys(): Set<String> {
        val s = HashSet<String>()
        fun add(items: List<HomeItem>) = items.forEach {
            when (it) {
                is HomeItem.App -> s.add(it.key)
                is HomeItem.Folder -> s.addAll(it.apps)
            }
        }
        pages.forEach { add(it) }
        add(dock)
        return s
    }

    /** 사라진 앱을 모든 곳에서 제거하고 빈 폴더/페이지를 정리 */
    fun prune(valid: Set<String>) {
        fun clean(items: MutableList<HomeItem>) {
            val itr = items.iterator()
            while (itr.hasNext()) {
                when (val it = itr.next()) {
                    is HomeItem.App -> if (it.key !in valid) itr.remove()
                    is HomeItem.Folder -> {
                        it.apps.retainAll(valid)
                        if (it.apps.isEmpty()) itr.remove()
                    }
                }
            }
        }
        pages.forEach { clean(it) }
        clean(dock)
        removeEmptyPages()
    }

    fun removeEmptyPages() {
        pages.removeAll { it.isEmpty() }
        if (pages.isEmpty()) pages.add(ArrayList())
    }
}

/** 실행 횟수/최근 사용/마지막 실행 시각 (제안, 파란 점에 사용) */
class Stats(private val prefs: SharedPreferences) {
    private val counts = HashMap<String, Int>()
    private val lastUsed = HashMap<String, Long>()
    val firstRun: Long

    init {
        if (!prefs.contains("first_run")) prefs.edit().putLong("first_run", System.currentTimeMillis()).apply()
        firstRun = prefs.getLong("first_run", System.currentTimeMillis())
        try {
            val o = JSONObject(prefs.getString("stats", "{}") ?: "{}")
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = o.getJSONArray(k)
                counts[k] = v.getInt(0)
                lastUsed[k] = v.getLong(1)
            }
        } catch (e: Exception) { }
    }

    fun record(key: String) {
        counts[key] = (counts[key] ?: 0) + 1
        lastUsed[key] = System.currentTimeMillis()
        val o = JSONObject()
        for ((k, c) in counts) o.put(k, JSONArray().put(c).put(lastUsed[k] ?: 0L))
        prefs.edit().putString("stats", o.toString()).apply()
    }

    fun lastOpened(key: String): Long = lastUsed[key] ?: 0L

    /** 많이, 최근에 쓴 앱일수록 높음 */
    fun score(key: String): Double {
        val c = counts[key] ?: return 0.0
        val ageH = (System.currentTimeMillis() - (lastUsed[key] ?: 0L)) / 3_600_000.0
        return c / (1.0 + ageH / 48.0)
    }

    /** iOS: 새로 설치/업데이트된 뒤 아직 열지 않은 앱 이름 앞에 파란 점 */
    fun showDot(app: AppInfo): Boolean {
        val changed = maxOf(app.installTime, app.updateTime)
        return changed > firstRun && changed > lastOpened(app.key)
    }
}

object Hangul {
    private val initials = charArrayOf(
        'ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'
    )
    private val base = mapOf('ㄲ' to 'ㄱ', 'ㄸ' to 'ㄷ', 'ㅃ' to 'ㅂ', 'ㅆ' to 'ㅅ', 'ㅉ' to 'ㅈ')
    val koreanIndex = listOf("ㄱ", "ㄴ", "ㄷ", "ㄹ", "ㅁ", "ㅂ", "ㅅ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ")

    /** 목록 색인용 머리글자: 한글은 초성(쌍자음은 기본 자음으로), 영문은 대문자, 나머지는 # */
    fun section(label: String): String {
        val ch = label.trim().firstOrNull() ?: return "#"
        if (ch in '가'..'힣') {
            val ini = initials[(ch.code - 0xAC00) / (21 * 28)]
            return (base[ini] ?: ini).toString()
        }
        if (ch in 'ㄱ'..'ㅎ') return (base[ch] ?: ch).toString()
        val up = ch.uppercaseChar()
        if (up in 'A'..'Z') return up.toString()
        return "#"
    }

    fun order(section: String): Int {
        val k = koreanIndex.indexOf(section)
        if (k >= 0) return k
        if (section.length == 1 && section[0] in 'A'..'Z') return 100 + (section[0] - 'A')
        return 1000
    }
}
