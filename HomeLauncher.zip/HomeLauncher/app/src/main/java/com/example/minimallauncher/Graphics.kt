package com.example.minimallauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

object IconFactory {
    /**
     * iOS 아이콘의 연속 곡률 모서리에 가까운 초타원(superellipse, n=5).
     * 애플 원본 모양을 복제한 것이 아니라 수학적 근사치.
     */
    fun squircle(left: Float, top: Float, size: Float): Path {
        val p = Path()
        val r = size / 2f
        val n = 5.0
        val steps = 120
        for (i in 0 until steps) {
            val t = 2 * PI * i / steps
            val c = cos(t)
            val s = sin(t)
            val x = left + r + r * (sign(c) * abs(c).pow(2.0 / n)).toFloat()
            val y = top + r + r * (sign(s) * abs(s).pow(2.0 / n)).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    /** 비트맵 바깥을 초타원 모양으로 깎아냄 (안티앨리어싱) */
    fun maskSquircle(bmp: Bitmap) {
        val c = Canvas(bmp)
        val p = squircle(0f, 0f, bmp.width.toFloat())
        p.fillType = Path.FillType.INVERSE_WINDING
        c.drawPath(p, clearPaint)
    }

    fun blank(px: Int): Bitmap {
        val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        Canvas(b).drawColor(0xFF8E8E93.toInt())
        maskSquircle(b)
        return b
    }

    fun drawableToBitmap(d: Drawable, px: Int): Bitmap {
        val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        d.setBounds(0, 0, px, px)
        d.draw(c)
        return b
    }

    /** 앱 아이콘을 꽉 찬 둥근 사각형으로 만든다 */
    fun appIcon(d: Drawable, px: Int): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (d is AdaptiveIconDrawable) {
            // 적응형 아이콘: 108 중 가운데 72가 보이는 영역 → 화면 크기에 맞춰 확대
            val full = px * 108f / 72f
            val off = (full - px) / 2f
            c.save()
            c.translate(-off, -off)
            d.background?.let { it.setBounds(0, 0, full.toInt(), full.toInt()); it.draw(c) }
            d.foreground?.let { it.setBounds(0, 0, full.toInt(), full.toInt()); it.draw(c) }
            c.restore()
        } else {
            val probe = drawableToBitmap(d, px)
            val i = (px * 0.06f).toInt()
            val corners = listOf(
                probe.getPixel(i, i), probe.getPixel(px - 1 - i, i),
                probe.getPixel(i, px - 1 - i), probe.getPixel(px - 1 - i, px - 1 - i)
            )
            if (corners.all { Color.alpha(it) > 200 }) {
                // 이미 사각형으로 꽉 찬 아이콘
                c.drawBitmap(probe, 0f, 0f, null)
            } else {
                // 모양이 있는 구형 아이콘: 흰 바탕 위에 가운데 배치
                c.drawColor(Color.WHITE)
                val inset = (px * 0.14f).toInt()
                d.setBounds(inset, inset, px - inset, px - inset)
                d.draw(c)
            }
            probe.recycle()
        }
        maskSquircle(bmp)
        return bmp
    }

    /** 홈 화면 폴더 아이콘: 반투명 판 위에 3×3 작은 아이콘 */
    fun folderIcon(icons: List<Bitmap>, px: Int): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x8C2A2A2E.toInt() }
        c.drawPath(squircle(0f, 0f, px.toFloat()), bg)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = px * 0.012f
            color = 0x33FFFFFF
        }
        c.drawPath(squircle(px * 0.006f, px * 0.006f, px * 0.988f), stroke)
        val pad = px * 0.12f
        val mini = px * 0.21f
        val gap = (px - pad * 2 - mini * 3) / 2f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        icons.take(9).forEachIndexed { idx, ic ->
            val x = pad + (idx % 3) * (mini + gap)
            val y = pad + (idx / 3) * (mini + gap)
            c.drawBitmap(ic, null, RectF(x, y, x + mini, y + mini), paint)
        }
        return bmp
    }
}

object Glass {
    /** 아이폰 iOS 26의 반투명 판 느낌을 흉내 낸 배경 (실제 흐림 효과는 삼성 폰에서 불가) */
    fun panel(color: Int, radius: Float, strokeColor: Int = 0x26FFFFFF, strokePx: Int = 2): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }
}

object Glyphs {
    /** 돋보기 */
    fun search(c: Canvas, cx: Float, cy: Float, size: Float, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.STROKE
            strokeWidth = size * 0.13f
            strokeCap = Paint.Cap.ROUND
        }
        val r = size * 0.32f
        val ox = cx - size * 0.08f
        val oy = cy - size * 0.08f
        c.drawCircle(ox, oy, r, p)
        val d = r * 0.7071f
        c.drawLine(ox + d, oy + d, cx + size * 0.42f, cy + size * 0.42f, p)
    }
}
