package com.example.minimallauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.text.TextPaint
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.OverScroller
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** 가로 페이지 넘김 (위젯 | 홈 페이지들 | 앱 보관함) */
class PagedView(context: Context) : ViewGroup(context) {
    var onScroll: ((Float) -> Unit)? = null
    var onPageSettled: ((Int) -> Unit)? = null
    var onMoving: ((Boolean) -> Unit)? = null
    /** 세로 제스처를 감지했을 때 (page, dy). true면 그 제스처를 소비 */
    var verticalHandler: ((Int, Float) -> Boolean)? = null
    var locked = false

    var page = 0
        private set

    private val scroller = OverScroller(context, DecelerateInterpolator(1.8f))
    private val vc = ViewConfiguration.get(context)
    private val slop = vc.scaledTouchSlop
    private val minFling = vc.scaledMinimumFlingVelocity * 4
    private val maxFling = vc.scaledMaximumFlingVelocity
    private var tracker: VelocityTracker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var dragging = false
    private var consumed = false
    private var verticalChecked = false
    private var settling = false

    val pageCount: Int get() = childCount

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val ws = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY)
        val hs = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
        for (i in 0 until childCount) getChildAt(i).measure(ws, hs)
        setMeasuredDimension(w, h)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        for (i in 0 until childCount) getChildAt(i).layout(i * w, 0, (i + 1) * w, b - t)
        if (changed && scroller.isFinished) scrollTo(page * w, 0)
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        if (width > 0) onScroll?.invoke(l.toFloat() / width)
    }

    fun snapTo(target: Int, animate: Boolean = true) {
        val p = target.coerceIn(0, max(0, childCount - 1))
        page = p
        val dest = p * width
        if (!animate || width == 0) {
            scroller.abortAnimation()
            scrollTo(dest, 0)
            settling = false
            onPageSettled?.invoke(p)
            onMoving?.invoke(false)
            return
        }
        val dx = dest - scrollX
        val dur = (260 + abs(dx) * 120 / max(1, width)).coerceAtMost(520)
        scroller.startScroll(scrollX, 0, dx, 0, dur)
        settling = true
        onMoving?.invoke(true)
        postInvalidateOnAnimation()
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollTo(scroller.currX, 0)
            postInvalidateOnAnimation()
        } else if (settling) {
            settling = false
            onPageSettled?.invoke(page)
            onMoving?.invoke(false)
        }
    }

    private fun track(ev: MotionEvent) {
        val t = tracker ?: VelocityTracker.obtain().also { tracker = it }
        t.addMovement(ev)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (locked) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; lastX = ev.x
                consumed = false; verticalChecked = false
                tracker?.recycle(); tracker = null
                track(ev)
                dragging = !scroller.isFinished
                if (dragging) {
                    scroller.abortAnimation(); settling = false
                    onMoving?.invoke(true)
                }
                return dragging
            }
            MotionEvent.ACTION_MOVE -> {
                track(ev)
                if (checkStart(ev)) return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
            }
        }
        return false
    }

    /** 가로 넘김 또는 세로 제스처 시작 여부 */
    private fun checkStart(ev: MotionEvent): Boolean {
        val dx = ev.x - downX
        val dy = ev.y - downY
        if (!dragging && abs(dx) > slop && abs(dx) > abs(dy)) {
            dragging = true
            lastX = ev.x
            parent?.requestDisallowInterceptTouchEvent(true)
            onMoving?.invoke(true)
            return true
        }
        if (!dragging && !verticalChecked && abs(dy) > slop * 1.5f && abs(dy) > abs(dx) * 1.3f) {
            verticalChecked = true
            if (verticalHandler?.invoke(page, dy) == true) {
                consumed = true
                return true
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (locked) return false
        track(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; lastX = ev.x
                consumed = false; verticalChecked = false
                if (!scroller.isFinished) { scroller.abortAnimation(); settling = false; dragging = true }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (consumed) return true
                if (!dragging) checkStart(ev)
                if (dragging) {
                    val delta = lastX - ev.x
                    lastX = ev.x
                    val maxX = (childCount - 1) * width
                    var nx = scrollX + delta
                    if (nx < 0 || nx > maxX) nx = scrollX + delta * 0.3f
                    scrollTo(nx.roundToInt(), 0)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging && !consumed && width > 0) {
                    val t = tracker
                    var vx = 0f
                    if (t != null) { t.computeCurrentVelocity(1000, maxFling.toFloat()); vx = t.xVelocity }
                    val pos = scrollX.toFloat() / width
                    val target = when {
                        ev.actionMasked == MotionEvent.ACTION_CANCEL -> pos.roundToInt()
                        vx < -minFling -> ceil(pos).toInt()
                        vx > minFling -> floor(pos).toInt()
                        else -> pos.roundToInt()
                    }
                    snapTo(target.coerceIn(page - 1, page + 1))
                } else if (dragging) {
                    snapTo(page)
                }
                dragging = false
                consumed = false
                tracker?.recycle(); tracker = null
                return true
            }
        }
        return true
    }
}

/** 홈 화면 한 페이지 (또는 폴더 한 페이지) 아이콘 격자 */
class GridPage(context: Context) : ViewGroup(context) {
    var cols = 4
    var rows = 6
    var cellW = 100
    var cellH = 100
    var padLeft = 0
    var padTop = 0
    var animateNext = false

    init { clipChildren = false; clipToPadding = false }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val ws = MeasureSpec.makeMeasureSpec(cellW, MeasureSpec.EXACTLY)
        val hs = MeasureSpec.makeMeasureSpec(cellH, MeasureSpec.EXACTLY)
        for (i in 0 until childCount) getChildAt(i).measure(ws, hs)
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val nl = padLeft + (i % cols) * cellW
            val nt = padTop + (i / cols) * cellH
            animateMove(v, nl, nt, animateNext, this)
            v.layout(nl, nt, nl + cellW, nt + cellH)
        }
        animateNext = false
    }

    /** 페이지 안 좌표 → 칸 번호 */
    fun cellAt(x: Float, y: Float): Int {
        val c = ((x - padLeft) / cellW).toInt().coerceIn(0, cols - 1)
        val r = ((y - padTop) / cellH).toInt().coerceIn(0, rows - 1)
        return r * cols + c
    }

    companion object {
        fun animateMove(v: View, nl: Int, nt: Int, animate: Boolean, parent: Any) {
            val iv = v as? IconView
            val sameParent = iv == null || iv.lastParent === parent
            if (animate && sameParent && v.isLaidOut && (v.left != nl || v.top != nt) && v.visibility == View.VISIBLE) {
                v.translationX = (v.left - nl).toFloat() + v.translationX
                v.translationY = (v.top - nt).toFloat() + v.translationY
                v.animate().translationX(0f).translationY(0f).setDuration(260)
                    .setInterpolator(DecelerateInterpolator(1.6f)).start()
            } else if (!animate && iv != null && iv.lastParent !== parent) {
                v.animate().cancel()
                v.translationX = 0f
                v.translationY = 0f
            }
            iv?.lastParent = parent
        }
    }
}

/** 독: 최대 4칸, 아이콘이 적으면 가운데 정렬 */
class DockRow(context: Context) : ViewGroup(context) {
    var slotW = 100
    var animateNext = false
    val capacity = 4

    init { clipChildren = false }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val ws = MeasureSpec.makeMeasureSpec(slotW, MeasureSpec.EXACTLY)
        val hs = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
        for (i in 0 until childCount) getChildAt(i).measure(ws, hs)
        setMeasuredDimension(w, h)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val start = (w - childCount * slotW) / 2
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val nl = start + i * slotW
            GridPage.animateMove(v, nl, 0, animateNext, this)
            v.layout(nl, 0, nl + slotW, b - t)
        }
        animateNext = false
    }

    /** 독 안 x좌표 → 삽입 위치 */
    fun slotAt(x: Float, count: Int): Int {
        val start = (width - count * slotW) / 2f
        return ((x - start) / slotW).toInt().coerceIn(0, max(0, count - 1))
    }
}

/** 오늘 보기 위젯 배치 정보 (열 수, 행 수) */
class WidgetSpan(val w: Int, val h: Int)

/** 위젯을 2열(넓은 화면 4열) 격자에 순서대로 채움 */
class WidgetGrid(context: Context) : ViewGroup(context) {
    var cols = 2
    var cell = 100
    var gap = 20
    var padLeft = 0
    var padTop = 0
    var padBottom = 0
    var animateNext = false
    private val rects = ArrayList<IntArray>()

    init { clipChildren = false; clipToPadding = false }

    private fun compute() {
        rects.clear()
        val occ = ArrayList<BooleanArray>()
        fun free(r: Int, c: Int, sw: Int, sh: Int): Boolean {
            if (c + sw > cols) return false
            for (rr in r until r + sh) {
                while (occ.size <= rr) occ.add(BooleanArray(cols))
                for (cc in c until c + sw) if (occ[rr][cc]) return false
            }
            return true
        }
        for (i in 0 until childCount) {
            val span = getChildAt(i).tag as? WidgetSpan ?: WidgetSpan(1, 1)
            val sw = min(span.w, cols)
            var placed = false
            var r = 0
            while (!placed) {
                for (c in 0 until cols) {
                    if (free(r, c, sw, span.h)) {
                        for (rr in r until r + span.h) for (cc in c until c + sw) occ[rr][cc] = true
                        val x = padLeft + c * (cell + gap)
                        val y = padTop + r * (cell + gap)
                        rects.add(intArrayOf(x, y, sw * cell + (sw - 1) * gap, span.h * cell + (span.h - 1) * gap))
                        placed = true
                        break
                    }
                }
                r++
            }
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        compute()
        var bottom = padTop
        for (i in 0 until childCount) {
            val rc = rects[i]
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(rc[2], MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(rc[3], MeasureSpec.EXACTLY)
            )
            bottom = max(bottom, rc[1] + rc[3])
        }
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), bottom + padBottom)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val rc = rects[i]
            if (animateNext && v.isLaidOut && v.visibility == View.VISIBLE && (v.left != rc[0] || v.top != rc[1])) {
                v.translationX = (v.left - rc[0]).toFloat()
                v.translationY = (v.top - rc[1]).toFloat()
                v.animate().translationX(0f).translationY(0f).setDuration(260).start()
            }
            v.layout(rc[0], rc[1], rc[0] + rc[2], rc[1] + rc[3])
        }
        animateNext = false
    }

    /** 손가락 위치(그리드 좌표)에 해당하는 위젯 순서 */
    fun indexAt(x: Float, y: Float): Int {
        var best = 0
        var bestD = Float.MAX_VALUE
        for (i in 0 until childCount) {
            val rc = rects.getOrNull(i) ?: continue
            if (x >= rc[0] && x <= rc[0] + rc[2] && y >= rc[1] && y <= rc[1] + rc[3]) return i
            val d = hypot(x - (rc[0] + rc[2] / 2f), y - (rc[1] + rc[3] / 2f))
            if (d < bestD) { bestD = d; best = i }
        }
        return best
    }
}

/** 위젯 한 칸: 모서리 둥글게 자르고, 길게 누르기/편집 모드 드래그/− 버튼 처리 */
class WidgetCell(context: Context, val spec: String, private val host: Host) : FrameLayout(context) {
    interface Host {
        fun isEditMode(): Boolean
        fun onWidgetLongPress(cell: WidgetCell, rawX: Float, rawY: Float)
        fun onWidgetDragMove(cell: WidgetCell, rawX: Float, rawY: Float)
        fun onWidgetDragEnd(cell: WidgetCell, rawX: Float, rawY: Float, cancelled: Boolean)
        fun onWidgetMinus(cell: WidgetCell)
    }

    val content = FrameLayout(context)
    var radius = 40f
    var showMinus = false
        set(v) { field = v; invalidate() }
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var longFired = false
    private var dragging = false
    private var minusDown = false
    private val minusBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6D1D1D6.toInt() }
    private val minusFg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1C1C1E.toInt(); strokeCap = Paint.Cap.ROUND }
    private var jiggle: android.animation.ObjectAnimator? = null

    private val longPress = Runnable {
        longFired = true
        parent?.requestDisallowInterceptTouchEvent(true)
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        host.onWidgetLongPress(this, downX, downY)
    }

    init {
        clipChildren = false
        setWillNotDraw(false)
        content.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        content.clipToOutline = true
        addView(content, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    fun setJiggle(on: Boolean) {
        if (on) {
            if (jiggle != null) return
            val a = android.animation.ObjectAnimator.ofFloat(this, "rotation", -0.8f, 0.8f)
            a.duration = 140
            a.repeatCount = android.animation.ValueAnimator.INFINITE
            a.repeatMode = android.animation.ValueAnimator.REVERSE
            a.startDelay = (Math.random() * 100).toLong()
            a.start()
            jiggle = a
        } else {
            jiggle?.cancel(); jiggle = null; rotation = 0f
        }
    }

    private fun minusR() = min(width, height) * 0.09f
    private fun hitMinus(x: Float, y: Float) = hypot(x - minusR() * 0.4f, y - minusR() * 0.4f) < minusR() * 1.8f

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        if (showMinus) {
            val r = minusR()
            val cx = r * 0.4f
            val cy = r * 0.4f
            canvas.drawCircle(cx, cy, r, minusBg)
            minusFg.strokeWidth = r * 0.22f
            canvas.drawLine(cx - r * 0.45f, cy, cx + r * 0.45f, cy, minusFg)
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY
                longFired = false; dragging = false; minusDown = false
                if (host.isEditMode()) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                postDelayed(longPress, IconView.LONG_PRESS_MS + 50)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!longFired && hypot(ev.rawX - downX, ev.rawY - downY) > slop) removeCallbacks(longPress)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(longPress)
        }
        return longFired
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (showMinus && hitMinus(ev.x, ev.y)) minusDown = true
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (minusDown) return true
                val dist = hypot(ev.rawX - downX, ev.rawY - downY)
                if (dragging) host.onWidgetDragMove(this, ev.rawX, ev.rawY)
                else if ((longFired || host.isEditMode()) && dist > slop) {
                    dragging = true
                    host.onWidgetDragMove(this, ev.rawX, ev.rawY)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                if (minusDown) { if (hitMinus(ev.x, ev.y)) host.onWidgetMinus(this) }
                else if (dragging || longFired) host.onWidgetDragEnd(this, ev.rawX, ev.rawY, false)
                longFired = false; dragging = false; minusDown = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (dragging || longFired) host.onWidgetDragEnd(this, ev.rawX, ev.rawY, true)
                longFired = false; dragging = false; minusDown = false
                return true
            }
        }
        return true
    }
}

/** 독 위 '검색' 알약. 페이지를 넘기는 동안/편집 모드에서는 페이지 점으로 바뀜 */
class SearchPill(context: Context) : View(context) {
    var onTap: (() -> Unit)? = null
    var onScrub: ((Int) -> Unit)? = null
    var pageCount = 1
        set(v) { field = v; requestLayout(); invalidate() }
    var current = 0f
        set(v) { field = v; if (showDots) invalidate() }
    var showDots = false
        set(v) { if (field != v) { field = v; requestLayout(); invalidate() } }
    var unit = 400f

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66303034 }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0x26FFFFFF; strokeWidth = 2f
    }
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6FFFFFF.toInt() }
    private val dotOn = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val dotOff = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFFFFF }
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var scrubbing = false
    private var lastScrub = -1
    private val startScrub = Runnable {
        scrubbing = true
        showDots = true
        parent?.requestDisallowInterceptTouchEvent(true)
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun pillH() = unit * 0.074f
    private fun dotGap() = unit * 0.034f

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = pillH()
        val w = if (showDots) max(h * 1.6f, pageCount * dotGap() + h * 0.7f) else {
            text.textSize = unit * 0.036f
            h * 0.55f + unit * 0.05f + text.measureText("검색") + h * 0.55f
        }
        setMeasuredDimension(w.toInt(), h.toInt())
    }

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        val r = RectF(1f, 1f, width - 1f, h - 1f)
        c.drawRoundRect(r, h / 2, h / 2, bg)
        c.drawRoundRect(r, h / 2, h / 2, border)
        if (showDots) {
            val total = pageCount * dotGap()
            val start = (width - total) / 2f + dotGap() / 2f
            val sel = current.roundToInt()
            for (i in 0 until pageCount) {
                c.drawCircle(start + i * dotGap(), h / 2, unit * 0.0095f, if (i == sel) dotOn else dotOff)
            }
        } else {
            text.textSize = unit * 0.036f
            val g = unit * 0.042f
            val x0 = h * 0.55f
            Glyphs.search(c, x0 + g / 2, h / 2, g, 0xE6FFFFFF.toInt())
            c.drawText("검색", x0 + unit * 0.05f + g * 0.1f, h / 2 - (text.ascent() + text.descent()) / 2, text)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; scrubbing = false; lastScrub = -1
                postDelayed(startScrub, 300)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scrubbing && abs(e.rawX - downX) > slop) removeCallbacks(startScrub)
                if (scrubbing) {
                    val dm = resources.displayMetrics.widthPixels
                    val idx = ((e.rawX / dm) * pageCount).toInt().coerceIn(0, pageCount - 1)
                    if (idx != lastScrub) {
                        lastScrub = idx
                        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        onScrub?.invoke(idx)
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(startScrub)
                if (!scrubbing && abs(e.rawX - downX) <= slop) onTap?.invoke()
                scrubbing = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(startScrub); scrubbing = false
                return true
            }
        }
        return true
    }
}
