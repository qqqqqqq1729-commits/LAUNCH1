package com.example.minimallauncher

import android.Manifest
import android.app.Activity
import android.app.ActivityOptions
import android.app.NotificationManager
import android.app.SearchManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import android.provider.Settings
import android.util.SizeF
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.window.OnBackInvokedDispatcher
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** 화면 크기에서 계산한 치수. 비율은 사용자 아이폰 스크린샷에서 잰 값 */
class Metrics(val w: Int, val h: Int, top: Int, bottom: Int, density: Float) {
    val wide = w / density >= 600f
    /**
     * 아이폰 화면 폭에 해당하는 기준 길이.
     * 아이폰은 세로/가로 비율이 약 2.17이라, 그보다 가로로 넓은 화면(폴드 등)은 높이에 맞춰 줄인다.
     */
    val unit: Float = min(if (!wide) w.toFloat() else min(w, h) * 0.62f, (h - top - bottom) / 2.05f)
    val cols = if (wide) 6 else 4
    val rows = if (wide) 5 else 6
    val iconPx = (unit * 0.162f).toInt()
    val labelPx = unit * 0.030f
    val dockH = (unit * 0.274f).toInt()
    val dockW = if (wide) min(w - (unit * 0.065f).toInt(), (unit * 1.05f).toInt()) else (w - unit * 0.065f).toInt()
    val dockSlot = ((dockW - unit * 0.052f) / 4f).toInt()
    val dockBottom = max(bottom * 0.55f, unit * 0.03f).toInt()
    val dockTop = h - dockBottom - dockH
    val pillH = (unit * 0.074f).toInt()
    val pillTop = dockTop - (unit * 0.05f).toInt() - pillH
    val gridTop = top + (unit * 0.05f).toInt()
    val gridMargin = if (wide) (w * 0.07f).toInt() else (w * 0.037f).toInt()
    val cellW = (w - gridMargin * 2) / cols
    val cellH = min((pillTop - (unit * 0.03f).toInt() - gridTop) / rows, (unit * 0.27f).toInt())
    val capacity = cols * rows
    val libCols = if (wide) 4 else 2
    val libInset = if (wide) (w * 0.07f).toInt() else (unit * 0.063f).toInt()
    val libGap = (unit * 0.051f).toInt()
    val card = (w - libInset * 2 - libGap * (libCols - 1)) / libCols
}

class MainActivity : Activity(), IconView.Host, WidgetCell.Host {

    sealed class Src {
        object Home : Src()
        object Dock : Src()
        class InFolder(val folder: HomeItem.Folder?) : Src()
        object Library : Src()
        object Search : Src()
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var store: LayoutStore
    private lateinit var stats: Stats
    private lateinit var launcherApps: LauncherApps
    private lateinit var widgetManager: AppWidgetManager
    private lateinit var widgetHost: AppWidgetHost
    private val main = Handler(Looper.getMainLooper())

    private var apps: List<AppInfo> = emptyList()
    private var appMap: Map<String, AppInfo> = emptyMap()
    private var loaded = false

    lateinit var metrics: Metrics
        private set
    var screenW = 0; private set
    var screenH = 0; private set
    var insetTop = 0; private set
    var insetBottom = 0; private set
    var imeBottom = 0; private set
    var editMode = false; private set

    private lateinit var root: FrameLayout
    private lateinit var scrim: View
    private lateinit var pager: PagedView
    private val homePages = ArrayList<GridPage>()
    private lateinit var todayScroll: ScrollView
    private lateinit var todayGrid: WidgetGrid
    private lateinit var libScroll: ScrollView
    private lateinit var libContent: LinearLayout
    private lateinit var dockBg: FrameLayout
    private lateinit var dock: DockRow
    private lateinit var pill: SearchPill
    private lateinit var editBar: FrameLayout
    private lateinit var overlayLayer: FrameLayout
    private val overlays = ArrayList<Overlay>()
    private val itemViews = HashMap<HomeItem, IconView>()
    private val widgetCells = ArrayList<WidgetCell>()
    private var hidePillDots: Runnable? = null
    private var reloadPending = false
    private var reloading = false

    // ---------------------------------------------------------------- 수명 주기

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        store = LayoutStore(prefs)
        store.load()
        stats = Stats(prefs)
        launcherApps = getSystemService(LauncherApps::class.java)
        widgetManager = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, 2048)
        window.setDecorFitsSystemWindows(false)
        if (Build.VERSION.SDK_INT >= 31) window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)

        buildSkeleton()
        setContentView(root)
        window.insetsController?.setSystemBarsAppearance(
            0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) { handleBack() }
        }
        launcherApps.registerCallback(appsCallback, main)
        Badges.listener = { refreshBadges() }
    }

    override fun onStart() {
        super.onStart()
        try { widgetHost.startListening() } catch (e: Exception) { }
    }

    override fun onStop() {
        super.onStop()
        try { widgetHost.stopListening() } catch (e: Exception) { }
    }

    override fun onPause() {
        super.onPause()
        if (dragItem == null) store.save()
    }

    override fun onResume() {
        super.onResume()
        if (loaded) refreshBadges()
    }

    override fun onDestroy() {
        launcherApps.unregisterCallback(appsCallback)
        Badges.listener = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // 이미 홈에 있는데 홈 버튼/제스처 → 첫 페이지로 (iOS 동작)
        val alreadyOnHome = hasWindowFocus() && (intent.flags and Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT) == 0
        if (dragItem != null) return
        if (overlays.isNotEmpty()) { closeAllOverlays(); return }
        if (editMode) { exitEditMode(); return }
        if (alreadyOnHome && pager.page != 1) pager.snapTo(1)
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onBackPressed() { handleBack() }

    private fun handleBack() {
        when {
            dragItem != null -> Unit
            overlays.isNotEmpty() -> closeOverlay(overlays.last())
            editMode -> exitEditMode()
            pager.page != 1 -> pager.snapTo(1)
        }
    }

    private val appsCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String, user: UserHandle) = reload()
        override fun onPackageAdded(packageName: String, user: UserHandle) = reload()
        override fun onPackageChanged(packageName: String, user: UserHandle) = reload()
        override fun onPackagesAvailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = reload()
        override fun onPackagesUnavailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) = reload()
    }

    // ---------------------------------------------------------------- 유틸

    fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    fun pressedBg(): Drawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(0x33FFFFFF))
        addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
    }

    private fun rootOffset(): IntArray { val a = IntArray(2); root.getLocationOnScreen(a); return a }

    /** 뷰의 위치를 루트(=오버레이) 좌표로 */
    fun rectOf(v: View): RectF {
        val a = IntArray(2); v.getLocationOnScreen(a)
        val o = rootOffset()
        return RectF((a[0] - o[0]).toFloat(), (a[1] - o[1]).toFloat(), (a[0] - o[0] + v.width).toFloat(), (a[1] - o[1] + v.height).toFloat())
    }

    private fun iconRect(v: IconView): RectF {
        val r = v.iconRectOnScreen()
        val o = rootOffset()
        r.offset(-o[0].toFloat(), -o[1].toFloat())
        return r
    }

    fun showKeyboard(v: View) {
        getSystemService(InputMethodManager::class.java).showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
    }

    fun hideKeyboard(v: View) {
        getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(v.windowToken, 0)
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    // ---------------------------------------------------------------- 뼈대

    private fun buildSkeleton() {
        root = FrameLayout(this)
        scrim = View(this)
        scrim.setBackgroundColor(Color.BLACK)
        scrim.alpha = 0f
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        pager = PagedView(this)
        root.addView(pager, FrameLayout.LayoutParams(-1, -1))

        dockBg = FrameLayout(this)
        dock = DockRow(this)
        dockBg.addView(dock, FrameLayout.LayoutParams(-1, -1))
        dockBg.clipChildren = false
        root.addView(dockBg, FrameLayout.LayoutParams(0, 0, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        pill = SearchPill(this)
        pill.onTap = { if (editMode) Unit else openOverlay(SpotlightOverlay(this)) }
        pill.onScrub = { pager.snapTo(it + 1) }
        root.addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        editBar = FrameLayout(this)
        editBar.visibility = View.GONE
        editBar.addView(barButton("편집") { showEditMenu(it) }, FrameLayout.LayoutParams(-2, -2, Gravity.START))
        editBar.addView(barButton("완료") { exitEditMode() }, FrameLayout.LayoutParams(-2, -2, Gravity.END))
        root.addView(editBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        overlayLayer = FrameLayout(this)
        root.addView(overlayLayer, FrameLayout.LayoutParams(-1, -1))

        pager.onScroll = { pos -> onPagerScroll(pos) }
        pager.onMoving = { moving ->
            if (moving) {
                hidePillDots?.let { main.removeCallbacks(it) }
                pill.showDots = true
            } else {
                val r = Runnable { if (!editMode) pill.showDots = false }
                hidePillDots = r
                main.postDelayed(r, 700)
            }
        }
        pager.onPageSettled = { p ->
            updateBlur()
            if (p == pager.pageCount - 1) buildLibrary()
        }
        pager.verticalHandler = { page, dy ->
            when {
                editMode || dragItem != null -> false
                page in 1..store.pages.size && dy > 0 -> { openOverlay(SpotlightOverlay(this)); true }
                page == pager.pageCount - 1 && dy > 0 && libScroll.scrollY == 0 -> {
                    openOverlay(LibrarySearchOverlay(this, false)); true
                }
                else -> false
            }
        }

        root.setOnApplyWindowInsetsListener { _, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            val ime = insets.getInsets(WindowInsets.Type.ime()).bottom
            val changed = bars.top != insetTop || bars.bottom != insetBottom
            insetTop = bars.top; insetBottom = bars.bottom
            if (ime != imeBottom) { imeBottom = ime; overlays.forEach { it.onInsetsChanged() } }
            if (changed && screenW > 0) root.post { relayout() }
            insets
        }
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val w = r - l; val h = b - t
            if (w > 0 && h > 0 && (w != screenW || h != screenH)) {
                screenW = w; screenH = h
                root.post { relayout() }
            }
        }
    }

    private fun barButton(text: String, onClick: (View) -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        t.paint.isFakeBoldText = true
        t.background = Glass.panel(0x80505055.toInt(), dp(18).toFloat(), 0x33FFFFFF, 1)
        t.setPadding(dp(16), dp(8), dp(16), dp(8))
        t.setOnClickListener { onClick(it) }
        return t
    }

    private fun relayout() {
        val old = if (::metrics.isInitialized) metrics.iconPx else 0
        metrics = Metrics(screenW, screenH, insetTop, insetBottom, resources.displayMetrics.density)
        pill.unit = metrics.unit
        (dockBg.layoutParams as FrameLayout.LayoutParams).apply {
            width = metrics.dockW; height = metrics.dockH; bottomMargin = metrics.dockBottom
        }
        dockBg.background = Glass.panel(0x4D3A3A40, metrics.dockH * 0.4f, 0x33FFFFFF, 2)
        dock.slotW = metrics.dockSlot
        (pill.layoutParams as FrameLayout.LayoutParams).bottomMargin = screenH - metrics.pillTop - metrics.pillH
        (editBar.layoutParams as FrameLayout.LayoutParams).apply {
            topMargin = insetTop + dp(6); leftMargin = dp(16); rightMargin = dp(16)
        }
        root.requestLayout()
        itemViews.clear()
        if (!loaded || abs(old - metrics.iconPx) > 2) reload() else buildAll()
    }

    // ---------------------------------------------------------------- 앱 목록

    private fun reload() {
        if (!::metrics.isInitialized) return
        if (dragItem != null || reloading) { reloadPending = true; return }
        reloading = true
        val px = metrics.iconPx
        Thread {
            val list = try { AppRepository.load(applicationContext, px) } catch (e: Exception) { null }
            main.post {
                reloading = false
                if (list != null) applyApps(list)
                if (reloadPending) { reloadPending = false; reload() }
            }
        }.start()
    }

    private fun applyApps(list: List<AppInfo>) {
        apps = list
        appMap = list.associateBy { it.key }
        if (list.isEmpty()) return
        val keys = appMap.keys
        // 0.2 초기 배치는 크기 계산 오류가 있어서 한 번만 새로 배치
        if (store.hasLayout && prefs.getInt("layout_v", 0) < 3) prefs.edit().remove("layout").apply()
        prefs.edit().putInt("layout_v", 3).apply()
        if (!store.hasLayout) {
            initialLayout()
            loaded = true
            buildAll()
            askBadgePermissionOnce()
            return
        }
        store.prune(keys)
        val placed = store.placedKeys()
        val toHome = prefs.getBoolean("new_to_home", true)
        for (a in list) {
            if (a.key !in store.known) {
                store.known.add(a.key)
                if (toHome && a.key !in placed) appendToHome(HomeItem.App(a.key))
            }
        }
        store.save()
        loaded = true
        itemViews.keys.retainAll { it in allItems() }
        buildAll()
    }

    private fun allItems(): Set<HomeItem> {
        val s = HashSet<HomeItem>()
        store.pages.forEach { s.addAll(it) }
        s.addAll(store.dock)
        return s
    }

    /** 기본 앱이 정해져 있으면 그것, 없으면 처리할 수 있는 첫 번째 앱 */
    private fun resolvePkg(i: Intent): String? {
        val best = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        if (best != null && best != "android" && best != packageName) return best
        val list = packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }
            .filter { it != packageName && it != "android" }
        return list.firstOrNull { p -> apps.any { it.pkg == p } }
    }

    private fun initialLayout() {
        val me = Process.myUserHandle()
        val dockPkgs = listOfNotNull(
            resolvePkg(Intent(Intent.ACTION_DIAL)),
            resolvePkg(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)),
            resolvePkg(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)),
            resolvePkg(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
                ?: resolvePkg(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)),
        ).distinct()
        store.pages.clear(); store.dock.clear(); store.known.clear()
        val used = HashSet<String>()
        for (p in dockPkgs) {
            val a = apps.firstOrNull { it.pkg == p && it.user == me } ?: continue
            if (store.dock.size < 4 && used.add(a.key)) store.dock.add(HomeItem.App(a.key))
        }
        val rest = apps.filter { it.key !in used }
        rest.chunked(metrics.capacity).forEach { chunk ->
            store.pages.add(chunk.map { HomeItem.App(it.key) as HomeItem }.toMutableList())
        }
        if (store.pages.isEmpty()) store.pages.add(ArrayList())
        store.known.addAll(apps.map { it.key })
        store.save()
    }

    private fun appendToHome(item: HomeItem) {
        if (store.pages.isEmpty()) store.pages.add(ArrayList())
        val last = store.pages.last()
        if (last.size >= metrics.capacity) store.pages.add(arrayListOf(item)) else last.add(item)
    }

    fun allApps(): List<AppInfo> = apps

    fun suggestions(n: Int): List<AppInfo> {
        val ranked = apps.filter { stats.score(it.key) > 0 }.sortedByDescending { stats.score(it.key) }.toMutableList()
        if (ranked.size < n) {
            val extra = (store.dock + store.pages.firstOrNull().orEmpty())
                .filterIsInstance<HomeItem.App>().mapNotNull { appMap[it.key] }
            for (a in extra) if (ranked.size < n && a !in ranked) ranked.add(a)
        }
        return ranked.take(n)
    }

    fun searchApps(q: String): List<AppInfo> {
        if (q.isBlank()) return emptyList()
        val ql = q.lowercase()
        return apps.mapNotNull { a ->
            val l = a.label.lowercase()
            val rank = when {
                l.startsWith(ql) -> 0
                l.split(' ').any { it.startsWith(ql) } -> 1
                l.contains(ql) -> 2
                else -> return@mapNotNull null
            }
            Triple(a, rank, stats.score(a.key))
        }.sortedWith(compareBy<Triple<AppInfo, Int, Double>> { it.second }.thenByDescending { it.third })
            .map { it.first }
    }

    // ---------------------------------------------------------------- 화면 구성

    /** 한 페이지 칸 수를 넘는 항목은 다음 페이지로 */
    private fun normalizePages() {
        var p = 0
        var changed = false
        while (p < store.pages.size) {
            while (store.pages[p].size > metrics.capacity) {
                val o = store.pages[p].removeAt(store.pages[p].size - 1)
                if (p + 1 >= store.pages.size) store.pages.add(ArrayList())
                store.pages[p + 1].add(0, o)
                changed = true
            }
            p++
        }
        if (changed) store.save()
    }

    private fun buildAll() {
        if (!loaded) return
        normalizePages()
        val keepPage = pager.page
        pager.removeAllViews()
        homePages.clear()
        buildToday()
        pager.addView(todayScroll)
        for (i in store.pages.indices) {
            val g = newHomePage()
            homePages.add(g)
            pager.addView(g)
            bindPage(i, false)
        }
        buildLibraryPage()
        pager.addView(libScroll)
        bindDock(false)
        pill.pageCount = store.pages.size
        // 처음 그릴 때는 첫 번째 홈 페이지(위젯 페이지 오른쪽)에서 시작
        val target = if (!builtOnce) 1 else keepPage
        builtOnce = true
        pager.post { pager.snapTo(target.coerceIn(0, pager.pageCount - 1), false) }
    }

    private var builtOnce = false

    private fun newHomePage(): GridPage {
        val g = GridPage(this)
        g.cols = metrics.cols; g.rows = metrics.rows
        g.cellW = metrics.cellW; g.cellH = metrics.cellH
        g.padLeft = metrics.gridMargin; g.padTop = metrics.gridTop
        g.setOnLongClickListener { if (!editMode) { it.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS); enterEditMode() }; true }
        g.setOnClickListener { if (editMode) exitEditMode() }
        return g
    }

    /** 페이지 수가 바뀌면 페이저를 다시 구성 */
    private fun syncPageCount() {
        if (homePages.size == store.pages.size) return
        val cur = pager.page
        pager.removeView(libScroll)
        while (homePages.size > store.pages.size) {
            val g = homePages.removeAt(homePages.size - 1)
            g.removeAllViews()
            pager.removeView(g)
        }
        while (homePages.size < store.pages.size) {
            val g = newHomePage()
            homePages.add(g)
            pager.addView(g)
        }
        pager.addView(libScroll)
        pill.pageCount = store.pages.size
        pager.snapTo(cur.coerceIn(0, pager.pageCount - 1), false)
    }

    private fun bindPage(i: Int, animate: Boolean) {
        val g = homePages.getOrNull(i) ?: return
        g.animateNext = animate
        g.removeAllViews()
        for (item in store.pages[i]) g.addView(viewFor(item, Src.Home))
    }

    private fun bindAllPages(animate: Boolean) {
        syncPageCount()
        for (i in store.pages.indices) bindPage(i, animate)
        bindDock(animate)
    }

    private fun bindDock(animate: Boolean) {
        dock.animateNext = animate
        dock.removeAllViews()
        for (item in store.dock) dock.addView(viewFor(item, Src.Dock))
    }

    private fun viewFor(item: HomeItem, src: Src): IconView {
        val v = itemViews.getOrPut(item) { IconView(this, this) }
        (v.parent as? ViewGroup)?.removeView(v)
        v.item = item
        v.payload = src
        v.iconSize = metrics.iconPx
        v.labelPx = metrics.labelPx
        v.showLabel = src != Src.Dock
        bindItem(v)
        return v
    }

    private fun bindItem(v: IconView) {
        when (val item = v.item) {
            is HomeItem.App -> {
                val a = appMap[item.key]
                v.app = a
                v.bitmap = a?.icon ?: IconFactory.blank(metrics.iconPx)
                v.label = a?.label ?: ""
                v.badge = a?.let { Badges.counts[it.pkg] } ?: 0
                v.dot = a != null && stats.showDot(a)
                v.showMinus = editMode
            }
            is HomeItem.Folder -> {
                val members = item.apps.mapNotNull { appMap[it] }
                v.app = null
                v.bitmap = IconFactory.folderIcon(members.map { it.icon }, metrics.iconPx)
                v.label = item.name
                v.badge = members.sumOf { Badges.counts[it.pkg] ?: 0 }
                v.dot = false
                v.showMinus = false
            }
            null -> Unit
        }
        v.visibility = if (v.item != null && v.item === dragItem) View.INVISIBLE else View.VISIBLE
        v.post { v.setJiggle(editMode) }
    }

    fun makeIcon(a: AppInfo, src: Src): IconView {
        val v = IconView(this, this)
        v.app = a
        v.payload = src
        v.bitmap = a.icon
        v.label = a.label
        v.iconSize = metrics.iconPx
        v.labelPx = metrics.labelPx
        v.dot = stats.showDot(a)
        if (src is Src.InFolder) v.badge = Badges.counts[a.pkg] ?: 0
        return v
    }

    private fun refreshBadges() {
        for (v in itemViews.values) bindItem(v)
        overlays.filterIsInstance<FolderOverlay>().forEach { o -> o.icons.forEach { it.badge = it.app?.let { a -> Badges.counts[a.pkg] } ?: 0 } }
    }

    fun saveAndRefresh() {
        store.save()
        bindAllPages(false)
    }

    private fun onPagerScroll(pos: Float) {
        val last = (pager.pageCount - 1).toFloat()
        val side = when {
            pos < 1f -> 1f - pos
            pos > last - 1f -> pos - (last - 1f)
            else -> 0f
        }.coerceIn(0f, 1f)
        scrim.alpha = side * 0.55f
        val a = 1f - side
        dockBg.alpha = a; pill.alpha = a
        val vis = if (a < 0.02f) View.INVISIBLE else View.VISIBLE
        dockBg.visibility = vis; pill.visibility = vis
        pill.current = pos - 1f
    }

    private fun updateBlur() {
        if (Build.VERSION.SDK_INT < 31) return
        val wm = getSystemService(WindowManager::class.java)
        if (!wm.isCrossWindowBlurEnabled) return
        val p = pager.page
        val on = overlays.isNotEmpty() || p == 0 || p == pager.pageCount - 1
        val lp = window.attributes
        val r = if (on) dp(28) else 0
        if (lp.blurBehindRadius != r) { lp.blurBehindRadius = r; window.attributes = lp }
    }

    // ---------------------------------------------------------------- 오늘 보기 (위젯)

    private fun buildToday() {
        if (!::todayScroll.isInitialized) {
            todayScroll = ScrollView(this)
            todayScroll.isVerticalScrollBarEnabled = false
            todayScroll.overScrollMode = View.OVER_SCROLL_NEVER
            todayScroll.clipChildren = false
            todayGrid = WidgetGrid(this)
            todayGrid.setOnLongClickListener { if (!editMode) enterEditMode(); true }
            todayGrid.setOnClickListener { if (editMode) exitEditMode() }
            todayScroll.addView(todayGrid, ViewGroup.LayoutParams(-1, -2))
        }
        (todayScroll.parent as? ViewGroup)?.removeView(todayScroll)
        todayGrid.cols = metrics.libCols
        todayGrid.cell = metrics.card
        todayGrid.gap = metrics.libGap
        todayGrid.padLeft = metrics.libInset
        todayGrid.padTop = metrics.gridTop
        todayGrid.padBottom = insetBottom + dp(40)
        todayGrid.removeAllViews()
        widgetCells.clear()
        val bad = ArrayList<String>()
        for (spec in store.widgets) {
            val cell = makeWidgetCell(spec)
            if (cell == null) { bad.add(spec); continue }
            widgetCells.add(cell)
            todayGrid.addView(cell)
        }
        if (bad.isNotEmpty()) { store.widgets.removeAll(bad); store.save() }
    }

    private fun makeWidgetCell(spec: String): WidgetCell? {
        val cell = WidgetCell(this, spec, this)
        cell.radius = metrics.card * 0.165f
        val v: View
        val span: WidgetSpan
        when {
            spec == "builtin:photo" -> { v = PhotoWidget(this) { askMediaPermission() }; span = WidgetSpan(2, 1) }
            spec == "builtin:calendar" -> { v = CalendarWidget(this) { requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), REQ_PERM) }; span = WidgetSpan(1, 1) }
            spec == "builtin:clock" -> {
                v = ClockWidget(this); span = WidgetSpan(1, 1)
                v.setOnClickListener { openIntent(Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)) }
            }
            spec == "builtin:battery" -> { v = BatteryWidget(this); span = WidgetSpan(1, 1) }
            spec.startsWith("aw:") -> {
                val id = spec.removePrefix("aw:").toIntOrNull() ?: return null
                val info = widgetManager.getAppWidgetInfo(id) ?: return null
                val hv: AppWidgetHostView = widgetHost.createView(this, id, info)
                val sw = if (info.minWidth > metrics.card * 1.05f) 2 else 1
                val sh = if (info.minHeight > metrics.card * 1.05f) 2 else 1
                span = WidgetSpan(sw, sh)
                val wpx = sw * metrics.card + (sw - 1) * metrics.libGap
                val hpx = sh * metrics.card + (sh - 1) * metrics.libGap
                val d = resources.displayMetrics.density
                try {
                    if (Build.VERSION.SDK_INT >= 31) {
                        hv.updateAppWidgetSize(Bundle(), listOf(SizeF(wpx / d, hpx / d)))
                    } else {
                        @Suppress("DEPRECATION")
                        hv.updateAppWidgetSize(null, (wpx / d).toInt(), (hpx / d).toInt(), (wpx / d).toInt(), (hpx / d).toInt())
                    }
                } catch (e: Exception) { }
                hv.setPadding(0, 0, 0, 0)
                v = hv
            }
            else -> return null
        }
        cell.tag = span
        cell.content.addView(v, FrameLayout.LayoutParams(-1, -1))
        cell.showMinus = editMode
        if (editMode) cell.post { cell.setJiggle(true) }
        return cell
    }

    private fun askMediaPermission() {
        val perms = when {
            Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        requestPermissions(perms, REQ_PERM)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            for (c in widgetCells) {
                val v = c.content.getChildAt(0)
                (v as? PhotoWidget)?.refresh()
                (v as? CalendarWidget)?.refresh()
            }
        }
    }

    fun addWidget(spec: String) {
        store.widgets.add(spec)
        store.save()
        buildToday()
        if (todayScroll.parent == null) pager.addView(todayScroll, 0)
        pager.snapTo(0)
        todayScroll.post { todayScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private var pendingWidgetId = -1

    fun pickAppWidget(p: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        val ok = try { widgetManager.bindAppWidgetIdIfAllowed(id, p.profile, p.provider, null) } catch (e: Exception) { false }
        if (ok) configureOrAdd(id, p)
        else {
            pendingWidgetId = id
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER_PROFILE, p.profile)
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) { widgetHost.deleteAppWidgetId(id) }
        }
    }

    private fun configureOrAdd(id: Int, p: AppWidgetProviderInfo?) {
        if (p?.configure != null) {
            pendingWidgetId = id
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
                return
            } catch (e: Exception) { }
        }
        addWidget("aw:$id")
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
        when (requestCode) {
            REQ_BIND -> if (resultCode == RESULT_OK) configureOrAdd(id, widgetManager.getAppWidgetInfo(id))
                else if (id >= 0) widgetHost.deleteAppWidgetId(id)
            REQ_CONFIG -> if (resultCode == RESULT_OK) addWidget("aw:$id")
                else if (id >= 0) widgetHost.deleteAppWidgetId(id)
        }
    }

    private fun removeWidget(cell: WidgetCell) {
        openOverlay(AlertOverlay(this, "위젯을 제거하겠습니까?", "이 위젯을 제거해도 앱이나 데이터는 삭제되지 않습니다.", listOf(
            AlertButton("제거", AlertButton.DESTRUCTIVE) {
                store.widgets.remove(cell.spec)
                if (cell.spec.startsWith("aw:")) cell.spec.removePrefix("aw:").toIntOrNull()?.let { widgetHost.deleteAppWidgetId(it) }
                store.save()
                widgetCells.remove(cell)
                todayGrid.animateNext = true
                todayGrid.removeView(cell)
            },
            AlertButton("취소", AlertButton.CANCEL) {},
        )))
    }

    // WidgetCell.Host
    override fun onWidgetLongPress(cell: WidgetCell, rawX: Float, rawY: Float) {
        val r = rectOf(cell)
        openOverlay(ContextMenuOverlay(this, r, null, listOf(
            listOf(MenuEntry("홈 화면 편집") { enterEditMode() }),
            listOf(MenuEntry("위젯 제거", destructive = true) { removeWidget(cell) }),
        )))
    }

    override fun onWidgetMinus(cell: WidgetCell) = removeWidget(cell)

    private var dragWidget: WidgetCell? = null
    private var widgetFloat: ImageView? = null
    private var widgetGrab = floatArrayOf(0f, 0f)

    override fun onWidgetDragMove(cell: WidgetCell, rawX: Float, rawY: Float) {
        if (dragging()) return
        val o = rootOffset()
        startWidgetDrag(cell, rawX - o[0], rawY - o[1])
    }

    override fun onWidgetDragEnd(cell: WidgetCell, rawX: Float, rawY: Float, cancelled: Boolean) {}

    private fun startWidgetDrag(cell: WidgetCell, x: Float, y: Float) {
        run {
            overlays.filterIsInstance<ContextMenuOverlay>().forEach { closeOverlay(it, animate = false) }
            if (!editMode) enterEditMode()
            dragWidget = cell
            val r = rectOf(cell)
            val bmp = Bitmap.createBitmap(max(1, cell.width), max(1, cell.height), Bitmap.Config.ARGB_8888)
            cell.content.draw(Canvas(bmp))
            val iv = ImageView(this)
            iv.setImageBitmap(bmp)
            iv.alpha = 0.92f
            root.addView(iv, FrameLayout.LayoutParams(cell.width, cell.height))
            iv.x = r.left; iv.y = r.top
            iv.scaleX = 1.04f; iv.scaleY = 1.04f
            widgetGrab = floatArrayOf(x - r.left, y - r.top)
            widgetFloat = iv
            cell.visibility = View.INVISIBLE
            pager.locked = true
        }
        moveWidgetDrag(x, y)
    }

    private fun moveWidgetDrag(x: Float, y: Float) {
        val cell = dragWidget ?: return
        val f = widgetFloat ?: return
        f.x = x - widgetGrab[0]; f.y = y - widgetGrab[1]
        // 위/아래 가장자리에서 자동 스크롤
        if (y < insetTop + dp(80)) todayScroll.scrollBy(0, -dp(14))
        else if (y > screenH - dp(100)) todayScroll.scrollBy(0, dp(14))
        val g = rectOf(todayGrid)
        val idx = todayGrid.indexAt(x - g.left, y - g.top)
        val cur = todayGrid.indexOfChild(cell)
        if (idx != cur && idx >= 0) {
            todayGrid.animateNext = true
            todayGrid.removeView(cell)
            todayGrid.addView(cell, idx)
            if (cur in store.widgets.indices) {
                val spec = store.widgets.removeAt(cur)
                store.widgets.add(idx.coerceIn(0, store.widgets.size), spec)
            }
        }
    }

    private fun endWidgetDrag() {
        val cell = dragWidget ?: return
        val f = widgetFloat
        if (f == null) { dragWidget = null; return }
        val r = rectOf(cell)
        f.animate().x(r.left).y(r.top).scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            root.removeView(f)
            cell.visibility = View.VISIBLE
        }.start()
        dragWidget = null; widgetFloat = null
        pager.locked = false
        store.save()
    }

    // ---------------------------------------------------------------- 앱 보관함

    private fun buildLibraryPage() {
        if (!::libScroll.isInitialized) {
            libScroll = ScrollView(this)
            libScroll.isVerticalScrollBarEnabled = false
            libScroll.overScrollMode = View.OVER_SCROLL_NEVER
            libContent = LinearLayout(this)
            libContent.orientation = LinearLayout.VERTICAL
            libScroll.addView(libContent, ViewGroup.LayoutParams(-1, -2))
        }
        (libScroll.parent as? ViewGroup)?.removeView(libScroll)
        buildLibrary()
    }

    private fun buildLibrary() {
        libContent.removeAllViews()
        val m = metrics
        libContent.setPadding(m.libInset, m.gridTop, m.libInset, insetBottom + dp(40))

        // 상단 검색창
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER
        bar.background = Glass.panel(0x80303034.toInt(), m.unit * 0.06f, 0x26FFFFFF, 2)
        bar.addView(GlyphView(this, GlyphView.SEARCH, 0xE6FFFFFF.toInt()), LinearLayout.LayoutParams((m.unit * 0.05f).toInt(), (m.unit * 0.05f).toInt()))
        val bt = TextView(this)
        bt.text = "앱 보관함"
        bt.setTextColor(0xE6FFFFFF.toInt())
        bt.setTextSize(TypedValue.COMPLEX_UNIT_PX, m.unit * 0.045f)
        bt.setPadding((m.unit * 0.025f).toInt(), 0, 0, 0)
        bar.addView(bt)
        bar.setOnClickListener { openOverlay(LibrarySearchOverlay(this, true)) }
        libContent.addView(bar, LinearLayout.LayoutParams(-1, (m.unit * 0.121f).toInt()).apply { bottomMargin = (m.unit * 0.083f).toInt() })

        // 카드 목록: 제안, 최근 추가된 항목, 카테고리들
        val cards = ArrayList<Triple<String, List<AppInfo>, Boolean>>()
        cards.add(Triple("제안", suggestions(4), false))
        val recent = apps.filter { it.installTime > 0 }.sortedByDescending { it.installTime }.take(30)
        cards.add(Triple("최근 추가된 항목", recent, true))
        val byCat = apps.groupBy { it.category }
        val cats = byCat.entries.sortedWith(
            compareByDescending<Map.Entry<String, List<AppInfo>>> { e -> e.value.sumOf { stats.score(it.key) } }
                .thenByDescending { it.value.size }
        )
        for ((name, list) in cats) {
            cards.add(Triple(name, list.sortedByDescending { stats.score(it.key) }, true))
        }

        var row: LinearLayout? = null
        cards.forEachIndexed { i, (name, list, cluster) ->
            if (i % m.libCols == 0) {
                row = LinearLayout(this).also {
                    it.orientation = LinearLayout.HORIZONTAL
                    libContent.addView(it, LinearLayout.LayoutParams(-1, -2))
                }
            }
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.addView(libraryCard(name, list, cluster), LinearLayout.LayoutParams(m.card, m.card))
            val label = TextView(this)
            label.text = name
            label.setTextColor(Color.WHITE)
            label.setTextSize(TypedValue.COMPLEX_UNIT_PX, m.unit * 0.032f)
            label.gravity = Gravity.CENTER
            label.maxLines = 1
            label.setShadowLayer(4f, 0f, 1f, 0x80000000.toInt())
            label.setPadding(0, (m.unit * 0.015f).toInt(), 0, (m.unit * 0.04f).toInt())
            col.addView(label, LinearLayout.LayoutParams(-1, -2))
            row?.addView(col, LinearLayout.LayoutParams(m.card, -2).apply {
                if (i % m.libCols != 0) leftMargin = m.libGap
            })
        }
    }

    private fun libraryCard(name: String, list: List<AppInfo>, cluster: Boolean): View {
        val m = metrics
        val card = FrameLayout(this)
        card.background = Glass.panel(0x4D505055, m.card * 0.165f, 0x33FFFFFF, 2)
        val big = (m.card * 0.395f).toInt()
        val pad = (m.card * 0.074f).toInt()
        val gap = m.card - pad * 2 - big * 2
        val showCluster = cluster && list.size > 4
        val bigApps = if (showCluster) list.take(3) else list.take(4)
        bigApps.forEachIndexed { i, a ->
            val v = makeIcon(a, Src.Library)
            v.showLabel = false
            v.iconSize = big
            v.dot = false
            card.addView(v, FrameLayout.LayoutParams(big, big).apply {
                leftMargin = pad + (i % 2) * (big + gap); topMargin = pad + (i / 2) * (big + gap)
            })
        }
        if (showCluster) {
            val cv = ClusterView(this, list.drop(3).take(4).map { it.icon })
            cv.setOnClickListener { openOverlay(FolderOverlay(this, null, name, list, rectOf(card), false)) }
            card.addView(cv, FrameLayout.LayoutParams(big, big).apply {
                leftMargin = pad + big + gap; topMargin = pad + big + gap
            })
        }
        return card
    }

    // ---------------------------------------------------------------- 편집 모드

    fun enterEditMode() {
        if (editMode) return
        editMode = true
        overlays.filterIsInstance<ContextMenuOverlay>().forEach { closeOverlay(it, animate = false) }
        for (v in itemViews.values) bindItem(v)
        for (c in widgetCells) { c.showMinus = true; c.setJiggle(true) }
        overlays.filterIsInstance<FolderOverlay>().forEach { o ->
            if (o.folder != null) o.icons.forEach { it.showMinus = it.app?.removable == true; it.setJiggle(true) }
        }
        editBar.visibility = View.VISIBLE
        editBar.alpha = 0f
        editBar.animate().alpha(1f).setDuration(200).start()
        pill.showDots = true
    }

    fun exitEditMode() {
        if (!editMode) return
        editMode = false
        store.removeEmptyPages()
        store.save()
        bindAllPages(false)
        for (c in widgetCells) { c.showMinus = false; c.setJiggle(false) }
        editBar.visibility = View.GONE
        pill.showDots = false
    }

    private fun showEditMenu(anchor: View) {
        val toHome = prefs.getBoolean("new_to_home", true)
        val notif = notificationAccess()
        openOverlay(ContextMenuOverlay(this, rectOf(anchor), null, listOf(
            listOf(MenuEntry("위젯 추가") { pager.snapTo(0); openWidgetPicker() }),
            listOf(
                MenuEntry((if (toHome) "✓ " else "") + "새로운 앱: 홈 화면에 추가") { prefs.edit().putBoolean("new_to_home", true).apply() },
                MenuEntry((if (!toHome) "✓ " else "") + "새로운 앱: 앱 보관함에만") { prefs.edit().putBoolean("new_to_home", false).apply() },
            ),
            listOf(MenuEntry(if (notif) "알림 배지: 켜짐" else "알림 배지 켜기") { openNotificationAccess() }),
        )))
    }

    private fun openWidgetPicker() {
        val providers = try { widgetManager.installedProviders } catch (e: Exception) { emptyList<AppWidgetProviderInfo>() }
        openOverlay(WidgetPickerOverlay(this, providers))
    }

    // ---------------------------------------------------------------- 실행, 메뉴

    fun launch(app: AppInfo, from: View?) {
        try {
            var opts: Bundle? = null
            var bounds: Rect? = null
            if (from != null && from.isAttachedToWindow) {
                val iv = from as? IconView
                val l = iv?.iconLeft()?.toInt() ?: 0
                val t = iv?.iconTop()?.toInt() ?: 0
                val s = iv?.iconSize ?: from.width
                opts = ActivityOptions.makeScaleUpAnimation(from, l, t, s, if (iv != null) s else from.height).toBundle()
                val a = IntArray(2); from.getLocationOnScreen(a)
                bounds = Rect(a[0] + l, a[1] + t, a[0] + l + s, a[1] + t + s)
            }
            launcherApps.startMainActivity(app.component, app.user, bounds, opts)
            val hadDot = stats.showDot(app)
            stats.record(app.key)
            if (hadDot) main.postDelayed({ for (v in itemViews.values) bindItem(v) }, 400)
            main.postDelayed({ closeAllOverlays(false) }, 350)
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, "앱을 열 수 없음", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    fun openIntent(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    fun webSearch(q: String) {
        try {
            startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            openIntent(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        }
        main.postDelayed({ closeAllOverlays(false) }, 350)
    }

    fun shortcutsFor(app: AppInfo): List<ShortcutInfo> {
        return try {
            if (!launcherApps.hasShortcutHostPermission()) return emptyList()
            val q = LauncherApps.ShortcutQuery()
            q.setPackage(app.pkg)
            q.setActivity(app.component)
            q.setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST)
            (launcherApps.getShortcuts(q, app.user) ?: emptyList())
                .filter { it.isEnabled }
                .sortedWith(compareBy<ShortcutInfo>({ !it.isDeclaredInManifest }, { it.rank }))
                .take(4)
        } catch (e: Exception) { emptyList() }
    }

    fun shortcutIcon(si: ShortcutInfo): Drawable? =
        try { launcherApps.getShortcutIconDrawable(si, resources.displayMetrics.densityDpi) } catch (e: Exception) { null }

    fun startShortcut(si: ShortcutInfo) {
        try { launcherApps.startShortcut(si, null, null) } catch (e: Exception) { }
    }

    private fun shareApp(a: AppInfo) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + a.pkg)
        openIntent(Intent.createChooser(i, a.label))
    }

    private fun uninstall(a: AppInfo) {
        openIntent(Intent(Intent.ACTION_DELETE, Uri.fromParts("package", a.pkg, null)))
    }

    private fun isPlaced(a: AppInfo) = a.key in store.placedKeys()

    fun showAppMenu(a: AppInfo, view: IconView?, anchor: RectF, preview: Bitmap?, src: Src) {
        val groups = ArrayList<List<MenuEntry>>()
        val sc = shortcutsFor(a).map { si -> MenuEntry(si.shortLabel?.toString() ?: "", shortcutIcon(si)) { startShortcut(si) } }
        if (sc.isNotEmpty()) groups.add(sc)
        groups.add(listOf(MenuEntry("앱 공유") { shareApp(a) }))
        when (src) {
            Src.Home, Src.Dock, is Src.InFolder -> groups.add(listOf(
                MenuEntry("홈 화면 편집") { enterEditMode() },
                MenuEntry("앱 제거", destructive = true) { askRemove(a, view?.item, (src as? Src.InFolder)?.folder) },
            ))
            Src.Library -> {
                val g = ArrayList<MenuEntry>()
                if (!isPlaced(a)) g.add(MenuEntry("홈 화면에 추가") { appendToHome(HomeItem.App(a.key)); store.save(); bindAllPages(false) })
                if (a.removable) g.add(MenuEntry("앱 삭제", destructive = true) { askDelete(a) })
                if (g.isNotEmpty()) groups.add(g)
            }
            Src.Search -> Unit
        }
        openOverlay(ContextMenuOverlay(this, anchor, preview, groups))
    }

    private fun askDelete(a: AppInfo) {
        openOverlay(AlertOverlay(this, "'${a.label}' 앱을 삭제하겠습니까?", "이 앱을 삭제하면 앱의 데이터도 삭제됩니다.", listOf(
            AlertButton("삭제", AlertButton.DESTRUCTIVE) { uninstall(a) },
            AlertButton("취소", AlertButton.CANCEL) {},
        )))
    }

    /** iOS의 '앱 제거': 앱 삭제 / 홈 화면에서 제거 / 취소 */
    private fun askRemove(a: AppInfo, item: HomeItem?, folder: HomeItem.Folder?) {
        val buttons = ArrayList<AlertButton>()
        if (a.removable) buttons.add(AlertButton("앱 삭제", AlertButton.DESTRUCTIVE) { askDelete(a) })
        buttons.add(AlertButton("홈 화면에서 제거", AlertButton.NORMAL) { removeFromHome(a, item, folder) })
        buttons.add(AlertButton("취소", AlertButton.CANCEL) {})
        openOverlay(AlertOverlay(this, "'${a.label}' 앱을 제거하겠습니까?", "홈 화면에서 제거하면 앱은 앱 보관함에 남습니다.", buttons))
    }

    private fun removeFromHome(a: AppInfo, item: HomeItem?, folder: HomeItem.Folder?) {
        if (folder != null) {
            folder.apps.remove(a.key)
            if (folder.apps.isEmpty()) removeItem(folder)
            overlays.filterIsInstance<FolderOverlay>().forEach { closeOverlay(it, animate = false) }
        } else if (item != null) {
            removeItem(item)
            itemViews.remove(item)
        }
        store.save()
        bindAllPages(true)
    }

    private fun removeItem(item: HomeItem) {
        store.pages.forEach { it.remove(item) }
        store.dock.remove(item)
    }

    // ---------------------------------------------------------------- IconView.Host

    override fun isEditMode(): Boolean = editMode

    override fun onIconClick(v: IconView) {
        if (editMode && v.item !is HomeItem.Folder) return
        when (val item = v.item) {
            is HomeItem.Folder -> {
                val members = item.apps.mapNotNull { appMap[it] }
                openOverlay(FolderOverlay(this, item, item.name, members, iconRect(v), false))
            }
            else -> v.app?.let { launch(it, v) }
        }
    }

    override fun onIconLongPress(v: IconView, rawX: Float, rawY: Float) {
        val src = v.payload as? Src ?: Src.Search
        val anchor = iconRect(v)
        val item = v.item
        if (item is HomeItem.Folder) {
            openOverlay(ContextMenuOverlay(this, anchor, v.bitmap, listOf(
                listOf(MenuEntry("이름 변경") {
                    openOverlay(FolderOverlay(this, item, item.name, item.apps.mapNotNull { appMap[it] }, null, true))
                }),
                listOf(MenuEntry("홈 화면 편집") { enterEditMode() }),
            )))
            return
        }
        val a = v.app ?: return
        showAppMenu(a, v, anchor, v.bitmap, src)
    }

    override fun onIconMinus(v: IconView) {
        val a = v.app ?: return
        val src = v.payload
        askRemove(a, v.item, (src as? Src.InFolder)?.folder)
    }

    // ---------------------------------------------------------------- 드래그로 옮기기

    private var dragItem: HomeItem? = null
    private var floatView: ImageView? = null
    private var grab = floatArrayOf(0f, 0f)
    private var pending: Runnable? = null
    private var pendingKey = ""
    private var folderTarget: HomeItem? = null

    override fun onIconDragMove(v: IconView, rawX: Float, rawY: Float) {
        if (dragging()) return
        if (!startDrag(v, rawX, rawY)) return
        val o = rootOffset()
        if (folderDrag != null) moveFolderDrag(rawX - o[0], rawY - o[1]) else updateDrag(rawX - o[0], rawY - o[1])
    }

    // 드래그가 시작된 뒤에는 dispatchTouchEvent가 처리 (아이콘이 재배치되며 터치가 취소되는 문제 방지)
    override fun onIconDragEnd(v: IconView, rawX: Float, rawY: Float, cancelled: Boolean) {}

    private fun dragging() = dragItem != null || folderDrag != null || dragWidget != null

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        if (!dragging()) return super.dispatchTouchEvent(ev)
        val o = rootOffset()
        val x = ev.rawX - o[0]; val y = ev.rawY - o[1]
        when (ev.actionMasked) {
            android.view.MotionEvent.ACTION_MOVE -> when {
                dragWidget != null -> moveWidgetDrag(x, y)
                folderDrag != null -> moveFolderDrag(x, y)
                else -> updateDrag(x, y)
            }
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                val cancel = ev.actionMasked == android.view.MotionEvent.ACTION_CANCEL
                when {
                    dragWidget != null -> endWidgetDrag()
                    folderDrag != null -> endFolderDrag()
                    else -> endDrag(cancel)
                }
            }
        }
        return true
    }

    private fun startDrag(v: IconView, rawX: Float, rawY: Float): Boolean {
        val src = v.payload as? Src ?: return false
        val o = rootOffset()
        val x = rawX - o[0]; val y = rawY - o[1]
        val fromRect = iconRect(v)
        val item: HomeItem
        when (src) {
            Src.Home, Src.Dock -> item = v.item ?: return false
            is Src.InFolder -> {
                val f = src.folder ?: return dragFromLibrary(v, x, y)
                val a = v.app ?: return false
                val fo = overlays.filterIsInstance<FolderOverlay>().lastOrNull { it.folder === f } ?: return false
                overlays.filterIsInstance<ContextMenuOverlay>().forEach { closeOverlay(it, animate = false) }
                if (!editMode) enterEditMode()
                folderDrag = fo
                folderDragKey = a.key
                v.visibility = View.INVISIBLE
                makeFloat(v.bitmap, x, y, fromRect)
                return true
            }
            Src.Library -> return dragFromLibrary(v, x, y)
            Src.Search -> return false
        }
        overlays.toList().forEach { closeOverlay(it, animate = false) }
        if (!editMode) enterEditMode()
        beginFloat(item, v.bitmap, x, y, fromRect)
        return true
    }

    private fun dragFromLibrary(v: IconView, x: Float, y: Float): Boolean {
        val a = v.app ?: return false
        if (isPlaced(a)) return false
        overlays.toList().forEach { closeOverlay(it, animate = false) }
        val item = HomeItem.App(a.key)
        val page = store.pages.size - 1
        insertWithCascade(page, store.pages[page].size, item)
        if (!editMode) enterEditMode()
        bindAllPages(false)
        pager.snapTo(store.pages.indexOfFirst { item in it } + 1)
        beginFloat(item, a.icon, x, y, RectF(x - metrics.iconPx / 2f, y - metrics.iconPx / 2f, x + metrics.iconPx / 2f, y + metrics.iconPx / 2f))
        return true
    }

    private fun beginFloat(item: HomeItem, bmp: Bitmap?, x: Float, y: Float, from: RectF) {
        dragItem = item
        itemViews[item]?.visibility = View.INVISIBLE
        makeFloat(bmp, x, y, from)
    }

    private fun makeFloat(bmp: Bitmap?, x: Float, y: Float, from: RectF) {
        val iv = ImageView(this)
        iv.setImageBitmap(bmp)
        val s = metrics.iconPx
        root.addView(iv, FrameLayout.LayoutParams(s, s))
        grab = floatArrayOf(x - from.centerX(), y - from.centerY())
        iv.x = from.centerX() - s / 2f; iv.y = from.centerY() - s / 2f
        iv.animate().scaleX(1.12f).scaleY(1.12f).setDuration(150).start()
        floatView = iv
        pager.locked = true
    }

    // 폴더 안에서 드래그: 폴더 판 안에서는 순서 바꾸기, 밖으로 나가면 홈 화면으로 꺼냄
    private var folderDrag: FolderOverlay? = null
    private var folderDragKey = ""

    private fun moveFolderDrag(x: Float, y: Float) {
        val fo = folderDrag ?: return
        val f = fo.folder ?: return
        val fv = floatView ?: return
        val s = metrics.iconPx
        fv.x = x - grab[0] - s / 2f
        fv.y = y - grab[1] - s / 2f
        val cx = x - grab[0]; val cy = y - grab[1]
        val panel = rectOf(fo.panel)
        if (panel.contains(cx, cy)) {
            val idx = fo.indexAt(cx, cy).coerceIn(0, f.apps.size - 1)
            val cur = f.apps.indexOf(folderDragKey)
            if (idx != cur && cur >= 0) {
                schedule("fmove-$idx", 140) {
                    val c = f.apps.indexOf(folderDragKey)
                    if (c >= 0) { f.apps.removeAt(c); f.apps.add(idx.coerceIn(0, f.apps.size), folderDragKey); fo.rebind() }
                }
            }
        } else {
            schedule("fout", 300) { pullOutOfFolder(fo, f) }
        }
    }

    private fun pullOutOfFolder(fo: FolderOverlay, f: HomeItem.Folder) {
        val key = folderDragKey
        val loc = locate(f)
        closeOverlay(fo, animate = true)
        folderDrag = null
        f.apps.remove(key)
        if (f.apps.isEmpty()) removeItem(f)
        val item = HomeItem.App(key)
        val page = (loc?.first ?: -1).takeIf { it >= 0 } ?: (pager.page - 1).coerceIn(0, store.pages.size - 1)
        dragItem = item
        insertWithCascade(page, store.pages[page].size, item)
        bindAllPages(false)
        if (pager.page != page + 1) pager.snapTo(page + 1)
    }

    private fun endFolderDrag() {
        clearPending()
        val fo = folderDrag ?: return
        folderDrag = null
        pager.locked = false
        val v = fo.iconFor(folderDragKey)
        val fv = floatView
        floatView = null
        if (fv != null && v != null && v.isAttachedToWindow) {
            val r = iconRect(v)
            fv.animate().x(r.left).y(r.top).scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
                root.removeView(fv); v.visibility = View.VISIBLE
            }.start()
        } else {
            fv?.let { root.removeView(it) }
            v?.visibility = View.VISIBLE
        }
        store.save()
        bindAllPages(false)
    }

    /** 항목의 위치: (페이지 번호, 순서). 독은 페이지 -1 */
    private fun locate(item: HomeItem): Pair<Int, Int>? {
        store.pages.forEachIndexed { pi, list -> val i = list.indexOf(item); if (i >= 0) return pi to i }
        val d = store.dock.indexOf(item)
        return if (d >= 0) -1 to d else null
    }

    /** 페이지가 넘치면 마지막 항목을 다음 페이지 앞으로 밀어냄 */
    private fun insertWithCascade(page: Int, index: Int, item: HomeItem) {
        while (store.pages.size <= page) store.pages.add(ArrayList())
        val list = store.pages[page]
        list.add(index.coerceIn(0, list.size), item)
        var p = page
        while (store.pages[p].size > metrics.capacity) {
            val overflow = store.pages[p].removeAt(store.pages[p].size - 1)
            if (p + 1 >= store.pages.size) store.pages.add(ArrayList())
            store.pages[p + 1].add(0, overflow)
            p++
        }
    }

    private fun moveDragTo(page: Int, index: Int) {
        val item = dragItem ?: return
        val loc = locate(item) ?: return
        if (loc.first == page && loc.second == index) return
        if (page == -1 && loc.first != -1 && store.dock.size >= dock.capacity) return
        if (loc.first == -1) store.dock.removeAt(loc.second) else store.pages[loc.first].removeAt(loc.second)
        if (page == -1) store.dock.add(index.coerceIn(0, store.dock.size), item)
        else insertWithCascade(page, index, item)
        syncPageCount()
        if (loc.first >= 0) bindPage(loc.first, true)
        if (page >= 0) for (p in page until store.pages.size) bindPage(p, p == page)
        bindDock(true)
    }

    private fun schedule(key: String, delay: Long, action: () -> Unit) {
        if (key == pendingKey) return
        pending?.let { main.removeCallbacks(it) }
        setFolderTarget(null)
        pendingKey = key
        val r = Runnable { pendingKey = ""; pending = null; action() }
        pending = r
        main.postDelayed(r, delay)
    }

    private fun clearPending() {
        pending?.let { main.removeCallbacks(it) }
        pending = null; pendingKey = ""
    }

    private fun setFolderTarget(item: HomeItem?) {
        if (folderTarget === item) return
        folderTarget?.let { itemViews[it]?.highlight = false }
        folderTarget = item
        item?.let { itemViews[it]?.highlight = true }
    }

    private fun updateDrag(x: Float, y: Float) {
        val f = floatView ?: return
        val item = dragItem ?: return
        val s = metrics.iconPx
        f.x = x - grab[0] - s / 2f
        f.y = y - grab[1] - s / 2f
        val cx = x - grab[0]; val cy = y - grab[1]

        // 독 위
        val dr = rectOf(dockBg)
        if (dockBg.visibility == View.VISIBLE && dr.contains(cx, cy)) {
            val inDock = store.dock.contains(item)
            val count = if (inDock) store.dock.size else store.dock.size + 1
            val lx = cx - dr.left
            val slot = dock.slotAt(lx, count)
            val target = store.dock.getOrNull(slot)
            if (target != null && target !== item && item is HomeItem.App && nearCenter(target, cx, cy)) {
                schedule("folder-dock-$slot", 450) { setFolderTarget(target) }
            } else if (inDock || store.dock.size < dock.capacity) {
                schedule("dock-$slot", 120) { moveDragTo(-1, slot) }
            }
            return
        }

        val page = pager.page - 1
        if (page < 0 || page >= store.pages.size) return
        // 가장자리 → 페이지 넘김
        val edge = screenW * 0.06f
        if (cx < edge && page > 0) {
            schedule("edge-left-$page", 550) {
                pager.snapTo(page)
                moveDragTo(page - 1, store.pages[page - 1].size)
            }
            return
        }
        if (cx > screenW - edge) {
            val list = store.pages[page]
            val isLast = page == store.pages.size - 1
            if (!isLast || list.any { it !== item }) {
                schedule("edge-right-$page", 550) {
                    if (isLast) { store.pages.add(ArrayList()); syncPageCount() }
                    pager.snapTo(page + 2)
                    moveDragTo(page + 1, store.pages[page + 1].size)
                }
            }
            return
        }
        val g = homePages[page]
        val gr = rectOf(g)
        val idx = g.cellAt(cx - gr.left, cy - gr.top)
        val list = store.pages[page]
        val target = list.getOrNull(idx)
        if (target != null && target !== item) {
            if (item is HomeItem.App && nearCenter(target, cx, cy)) {
                schedule("folder-$page-$idx", 450) { setFolderTarget(target) }
            } else {
                schedule("move-$page-$idx", 140) { moveDragTo(page, idx) }
            }
        } else if (target == null) {
            val end = if (list.contains(item)) list.size - 1 else list.size
            schedule("move-$page-end", 140) { moveDragTo(page, end) }
        }
    }

    private fun nearCenter(target: HomeItem, x: Float, y: Float): Boolean {
        val v = itemViews[target] ?: return false
        val r = iconRect(v)
        val inset = r.width() * 0.22f
        return x > r.left + inset && x < r.right - inset && y > r.top + inset && y < r.bottom - inset
    }

    private fun endDrag(cancelled: Boolean) {
        clearPending()
        val item = dragItem ?: return
        val target = folderTarget
        setFolderTarget(null)
        if (!cancelled && target != null && item is HomeItem.App) {
            val loc = locate(item)
            if (loc != null) {
                if (loc.first == -1) store.dock.removeAt(loc.second) else store.pages[loc.first].removeAt(loc.second)
            }
            itemViews.remove(item)
            when (target) {
                is HomeItem.Folder -> target.apps.add(item.key)
                is HomeItem.App -> {
                    val name = appMap[target.key]?.category?.takeIf { it != Categories.OTHER } ?: "폴더"
                    val folder = HomeItem.Folder(name, mutableListOf(target.key, item.key))
                    val tl = locate(target)
                    if (tl != null) {
                        if (tl.first == -1) store.dock[tl.second] = folder else store.pages[tl.first][tl.second] = folder
                    }
                    itemViews.remove(target)
                }
            }
            floatView?.let { fv -> fv.animate().alpha(0f).scaleX(0.5f).scaleY(0.5f).setDuration(180).withEndAction { root.removeView(fv) }.start() }
            dragItem = null; floatView = null
            pager.locked = false
            store.save()
            bindAllPages(true)
        } else {
            dragItem = null
            val fv = floatView
            floatView = null
            pager.locked = false
            val v = itemViews[item]
            if (fv != null && v != null && v.isAttachedToWindow) {
                val r = iconRect(v)
                fv.animate().x(r.left).y(r.top).scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
                    root.removeView(fv); v.visibility = View.VISIBLE
                }.start()
            } else {
                fv?.let { root.removeView(it) }
                v?.visibility = View.VISIBLE
            }
            store.save()
        }
        if (reloadPending) { reloadPending = false; reload() }
    }

    // ---------------------------------------------------------------- 오버레이

    fun openOverlay(o: Overlay) {
        if (dragItem != null) return
        o.setBackgroundColor(o.dimColor)
        overlayLayer.addView(o, FrameLayout.LayoutParams(-1, -1))
        overlays.add(o)
        o.onShown()
        updateBlur()
    }

    fun closeOverlay(o: Overlay, animate: Boolean = true) {
        if (!overlays.remove(o)) return
        o.onHidden()
        if (animate) o.animate().alpha(0f).setDuration(160).withEndAction { overlayLayer.removeView(o) }.start()
        else overlayLayer.removeView(o)
        updateBlur()
    }

    private fun closeAllOverlays(animate: Boolean = true) {
        overlays.toList().forEach { closeOverlay(it, animate) }
    }

    // ---------------------------------------------------------------- 알림 배지 권한

    private fun notificationAccess(): Boolean =
        getSystemService(NotificationManager::class.java)
            .isNotificationListenerAccessGranted(ComponentName(this, BadgeService::class.java))

    private fun openNotificationAccess() {
        val detail = Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
            .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, ComponentName(this, BadgeService::class.java).flattenToString())
        try { startActivity(detail) } catch (e: Exception) { openIntent(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
    }

    private fun askBadgePermissionOnce() {
        if (prefs.getBoolean("asked_badges", false) || notificationAccess()) return
        prefs.edit().putBoolean("asked_badges", true).apply()
        main.postDelayed({
            openOverlay(AlertOverlay(this, "알림 배지를 표시할까요?", "앱 아이콘에 빨간 알림 숫자를 띄우려면 '알림 접근'을 허용해야 합니다.", listOf(
                AlertButton("나중에", AlertButton.NORMAL) {},
                AlertButton("허용하기", AlertButton.CANCEL) { openNotificationAccess() },
            )))
        }, 600)
    }

    companion object {
        const val REQ_PERM = 11
        const val REQ_BIND = 12
        const val REQ_CONFIG = 13
    }
}

/** 앱 보관함 카드 오른쪽 아래 작은 아이콘 4개 묶음 */
class ClusterView(context: Context, private val icons: List<Bitmap>) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    override fun onDraw(c: Canvas) {
        val s = width * 0.43f
        val gap = width - s * 2
        icons.take(4).forEachIndexed { i, b ->
            val x = (i % 2) * (s + gap)
            val y = (i / 2) * (s + gap)
            c.drawBitmap(b, null, RectF(x, y, x + s, y + s), p)
        }
    }
}
