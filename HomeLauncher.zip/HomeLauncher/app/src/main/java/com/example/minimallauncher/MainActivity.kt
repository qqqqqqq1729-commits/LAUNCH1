package com.example.minimallauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

data class AppEntry(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val icon: Bitmap,
    val category: Int,
    val isNew: Boolean,
)

class MainActivity : Activity() {

    private lateinit var pm: PackageManager
    private lateinit var prefs: SharedPreferences

    private var apps: List<AppEntry> = emptyList()
    private var appByPkg: Map<String, AppEntry> = emptyMap()

    private lateinit var root: FrameLayout
    private lateinit var pager: Pager
    private lateinit var pagesRow: LinearLayout
    private lateinit var homeScroll: ScrollView
    private lateinit var homeContent: LinearLayout
    private lateinit var libScroll: ScrollView
    private lateinit var libContent: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var searchPill: TextView

    private var searchOverlay: View? = null
    private var overlayBox: LinearLayout? = null

    private var insetTop = 0
    private var insetBottom = 0
    private var imeBottom = 0
    private var pageW = 0
    private var dirty = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            reload()
        }
    }

    // ------------------------------------------------------------------ 생명주기

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pm = packageManager
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        window.setDecorFitsSystemWindows(false)

        buildUi()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(pkgReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(pkgReceiver, filter)
        }

        reload()
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (dirty) {
            dirty = false
            rebuild()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // 홈 버튼을 누르면 첫 페이지 맨 위로
        closeSearch()
        pager.goTo(0)
        homeScroll.smoothScrollTo(0, 0)
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            searchOverlay != null -> closeSearch()
            pager.page == 1 -> pager.goTo(0)
            else -> Unit // 런처는 뒤로가기를 무시
        }
    }

    // ------------------------------------------------------------------ UI 뼈대

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun buildUi() {
        root = FrameLayout(this)

        pager = Pager(this)
        pagesRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        homeScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        homeContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        homeScroll.addView(homeContent, ViewGroup.LayoutParams(-1, -2))

        libScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        libContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        libScroll.addView(libContent, ViewGroup.LayoutParams(-1, -2))

        val initialW = resources.displayMetrics.widthPixels
        pagesRow.addView(homeScroll, LinearLayout.LayoutParams(initialW, -1))
        pagesRow.addView(libScroll, LinearLayout.LayoutParams(initialW, -1))
        pager.addView(pagesRow, FrameLayout.LayoutParams(-2, -1))
        root.addView(pager, FrameLayout.LayoutParams(-1, -1))

        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundBg(0x663A4A8A, dp(34), 0x33FFFFFF)
            setPadding(dp(8), 0, dp(8), 0)
        }
        root.addView(dock, FrameLayout.LayoutParams(-1, dp(96), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        searchPill = TextView(this).apply {
            text = "검색"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            background = roundBg(0xB3151A33.toInt(), dp(22), 0x33FFFFFF)
            setPadding(dp(16), dp(9), dp(20), dp(9))
            setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_search, 0, 0, 0)
            compoundDrawablePadding = dp(6)
            setOnClickListener { openSearch() }
        }
        root.addView(searchPill, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        pager.setOnScrollChangeListener { _, x, _, _, _ ->
            val a = (1f - x.toFloat() / max(pageW, 1)).coerceIn(0f, 1f)
            dock.alpha = a
            searchPill.alpha = a
            val vis = if (a < 0.02f) View.GONE else View.VISIBLE
            dock.visibility = vis
            searchPill.visibility = vis
        }

        pager.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            val w = r - l
            if (w > 0 && w != pageW) {
                pageW = w
                pager.pageWidth = w
                for (i in 0 until pagesRow.childCount) {
                    pagesRow.getChildAt(i).layoutParams.width = w
                }
                pagesRow.requestLayout()
                rebuild()
                pager.post { pager.goTo(pager.page, false) }
            }
        }

        root.setOnApplyWindowInsetsListener { _, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            val ime = insets.getInsets(WindowInsets.Type.ime())
            val changed = bars.top != insetTop || bars.bottom != insetBottom
            insetTop = bars.top
            insetBottom = bars.bottom
            imeBottom = ime.bottom
            if (changed) rebuild()
            updateOverlayPadding()
            insets
        }

        setContentView(root)
    }

    // ------------------------------------------------------------------ 앱 목록

    private fun reload() {
        Thread {
            val list = loadApps()
            runOnUiThread {
                apps = list
                appByPkg = list.associateBy { it.pkg }
                rebuild()
            }
        }.start()
    }

    private fun loadApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val launched = prefs.getStringSet("launched", emptySet()) ?: emptySet()
        val now = System.currentTimeMillis()
        val px = dp(64)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { ri ->
                val pkg = ri.activityInfo.packageName
                val installed = try {
                    pm.getPackageInfo(pkg, 0).firstInstallTime
                } catch (e: Exception) {
                    0L
                }
                AppEntry(
                    label = ri.loadLabel(pm).toString(),
                    pkg = pkg,
                    component = ComponentName(pkg, ri.activityInfo.name),
                    icon = squareIcon(ri.loadIcon(pm), px),
                    category = ri.activityInfo.applicationInfo.category,
                    isNew = now - installed < 3L * 24 * 3600 * 1000 && pkg !in launched,
                )
            }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    /** 어떤 아이콘이든 같은 둥근 사각형 안에 담는다. */
    private fun squareIcon(d: Drawable, px: Int): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (d is AdaptiveIconDrawable) {
            val scale = px / 72f
            val full = (108 * scale).toInt()
            val off = 18 * scale
            c.translate(-off, -off)
            d.background?.let { it.setBounds(0, 0, full, full); it.draw(c) }
            d.foreground?.let { it.setBounds(0, 0, full, full); it.draw(c) }
        } else {
            c.drawColor(0xFFF2F2F7.toInt())
            val inset = (px * 0.12f).toInt()
            d.setBounds(inset, inset, px - inset, px - inset)
            d.draw(c)
        }
        return bmp
    }

    // ------------------------------------------------------------------ 설정 저장소

    private fun resolvePkg(intent: Intent): String? {
        val best = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        if (best != null && best != "android" && best != packageName) return best
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName }
            .firstOrNull { it != packageName }
    }

    private fun mainSelector(category: String): Intent =
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, category)

    private fun defaultPinned(): List<String> = listOfNotNull(
        resolvePkg(Intent(Settings.ACTION_SETTINGS)),
        resolvePkg(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)),
        resolvePkg(mainSelector(Intent.CATEGORY_APP_GALLERY)),
        resolvePkg(mainSelector(Intent.CATEGORY_APP_CALENDAR)),
        resolvePkg(mainSelector(Intent.CATEGORY_APP_CALCULATOR)),
        resolvePkg(mainSelector(Intent.CATEGORY_APP_MUSIC)),
        resolvePkg(mainSelector(Intent.CATEGORY_APP_MAPS)),
        resolvePkg(mainSelector(Intent.CATEGORY_APP_EMAIL)),
    ).distinct()

    private fun defaultDock(): List<String> = listOf(
        resolvePkg(Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))),
        resolvePkg(mainSelector(Intent.CATEGORY_APP_MESSAGING)),
        resolvePkg(mainSelector(Intent.CATEGORY_APP_BROWSER)),
        resolvePkg(mainSelector(Intent.CATEGORY_APP_MARKET)),
    ).map { it ?: "" }

    private fun pinnedList(): MutableList<String> {
        val s = prefs.getString("pinned", null)
        if (s == null) {
            val d = defaultPinned().toMutableList()
            savePinned(d)
            return d
        }
        return s.split(",").filter { it.isNotBlank() }.toMutableList()
    }

    private fun savePinned(l: List<String>) {
        prefs.edit().putString("pinned", l.joinToString(",")).apply()
    }

    private fun dockList(): MutableList<String> {
        val s = prefs.getString("dock", null)
        val list = if (s == null) {
            defaultDock().toMutableList().also { saveDock(it) }
        } else {
            s.split("|").toMutableList()
        }
        while (list.size < 4) list.add("")
        return list
    }

    private fun saveDock(l: List<String>) {
        prefs.edit().putString("dock", l.joinToString("|")).apply()
    }

    private fun markLaunched(pkg: String) {
        val set = (prefs.getStringSet("launched", emptySet()) ?: emptySet()).toMutableSet()
        if (set.add(pkg)) {
            prefs.edit().putStringSet("launched", set).apply()
            dirty = true
        }
    }

    // ------------------------------------------------------------------ 화면 구성

    private fun cols(): Int = (pageW / dp(88)).coerceIn(4, 8)
    private fun sidePad(): Int = dp(14)
    private fun colW(): Int = (pageW - 2 * sidePad()) / cols()
    private fun dockH(): Int = dp(96)

    private fun rebuild() {
        if (pageW == 0) return
        layoutDockAndPill()
        buildHome()
        buildLibrary()
        buildDock()
    }

    private fun layoutDockAndPill() {
        val dockW = min(pageW - dp(24), dp(560))
        (dock.layoutParams as FrameLayout.LayoutParams).apply {
            width = dockW
            bottomMargin = insetBottom + dp(12)
        }
        dock.requestLayout()
        (searchPill.layoutParams as FrameLayout.LayoutParams).apply {
            bottomMargin = insetBottom + dp(12) + dockH() + dp(14)
        }
        searchPill.requestLayout()
    }

    private fun buildHome() {
        homeContent.removeAllViews()
        homeContent.setPadding(
            sidePad(), insetTop + dp(16), sidePad(),
            insetBottom + dockH() + dp(96)
        )

        val cw = colW()
        val ws = cw * 2 - dp(12)

        val widgets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        widgets.addView(
            widgetCell(ClockView(this), "시계", ws, cw * 2) { openClock() },
            LinearLayout.LayoutParams(cw * 2, -2)
        )
        widgets.addView(
            widgetCell(CalendarView(this), "캘린더", ws, cw * 2) { openCalendar() },
            LinearLayout.LayoutParams(cw * 2, -2)
        )
        homeContent.addView(widgets, LinearLayout.LayoutParams(-1, -2))

        val pinned = pinnedList().mapNotNull { appByPkg[it] }
        pinned.chunked(cols()).forEach { rowApps ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { app ->
                row.addView(
                    tile(app, true) { v -> showMenu(v, app) },
                    LinearLayout.LayoutParams(cw, -2)
                )
            }
            homeContent.addView(row, LinearLayout.LayoutParams(-1, -2))
        }

        if (pinned.isEmpty()) {
            homeContent.addView(TextView(this).apply {
                text = "오른쪽으로 넘겨서 앱 보관함을 열고,\n앱을 길게 눌러 홈 화면에 추가하세요."
                setTextColor(0xCCFFFFFF.toInt())
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, dp(24), 0, 0)
            })
        }
    }

    private fun widgetCell(content: View, label: String, size: Int, cellW: Int, onClick: () -> Unit): View {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(6), 0, dp(10))
        }
        cell.addView(content, LinearLayout.LayoutParams(size, size))
        cell.addView(TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 12f
            setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
            setPadding(0, dp(4), 0, 0)
        })
        cell.setOnClickListener { onClick() }
        return cell
    }

    private fun categoryName(c: Int): String = when (c) {
        ApplicationInfo.CATEGORY_SOCIAL -> "소셜"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "생산성"
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> "엔터테인먼트"
        ApplicationInfo.CATEGORY_MAPS, ApplicationInfo.CATEGORY_NEWS -> "정보 및 지도"
        ApplicationInfo.CATEGORY_GAME -> "게임"
        else -> "기타"
    }

    private fun buildLibrary() {
        libContent.removeAllViews()
        // 광고 자리 없이 카드가 맨 위부터 시작
        libContent.setPadding(sidePad(), insetTop + dp(12), sidePad(), insetBottom + dp(24))

        val order = listOf("소셜", "생산성", "엔터테인먼트", "정보 및 지도", "게임", "기타")
        val groups = LinkedHashMap<String, MutableList<AppEntry>>()
        order.forEach { groups[it] = mutableListOf() }
        apps.forEach { groups.getValue(categoryName(it.category)).add(it) }

        val cw = colW()
        groups.filter { it.value.isNotEmpty() }.forEach { (name, list) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundBg(0x66202436, dp(28), 0x33FFFFFF)
                setPadding(dp(4), dp(12), dp(4), dp(8))
            }
            card.addView(TextView(this).apply {
                text = "$name  ${list.size}"
                setTextColor(Color.WHITE)
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(14), 0, 0, dp(4))
            })
            val inner = (pageW - 2 * sidePad() - dp(8)) / cols()
            list.chunked(cols()).forEach { rowApps ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                rowApps.forEach { app ->
                    row.addView(
                        tile(app, true) { v -> showMenu(v, app) },
                        LinearLayout.LayoutParams(inner, -2)
                    )
                }
                card.addView(row)
            }
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
            libContent.addView(card, lp)
        }
        if (cw == 0) return
    }

    private fun buildDock() {
        dock.removeAllViews()
        val pkgs = dockList()
        for (i in 0 until 4) {
            val app = appByPkg[pkgs[i]]
            val slot = LinearLayout(this).apply { gravity = Gravity.CENTER }
            if (app != null) {
                slot.addView(tile(app, false) { chooseDockApp(i) })
            } else {
                slot.setOnLongClickListener { chooseDockApp(i); true }
            }
            dock.addView(slot, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    /** 앱 아이콘 + 이름 한 칸 */
    private fun tile(app: AppEntry, showLabel: Boolean, onLong: (View) -> Unit): View {
        val size = min(dp(60), max(dp(40), colW() - dp(14)))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val icon = ImageView(this).apply {
            setImageBitmap(app.icon)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, view.width * 0.225f)
                }
            }
            clipToOutline = true
        }
        col.addView(icon, LinearLayout.LayoutParams(size, size))
        if (showLabel) {
            col.addView(TextView(this).apply {
                text = app.label
                setTextColor(Color.WHITE)
                textSize = 12f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
                setPadding(dp(2), dp(4), dp(2), 0)
                if (app.isNew) {
                    val dot = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(0xFF4DA3FF.toInt())
                        setSize(dp(8), dp(8))
                    }
                    setCompoundDrawablesRelativeWithIntrinsicBounds(dot, null, null, null)
                    compoundDrawablePadding = dp(4)
                }
            }, LinearLayout.LayoutParams(-1, -2))
        }
        col.setOnClickListener { launch(app) }
        col.setOnLongClickListener { onLong(it); true }
        return col
    }

    // ------------------------------------------------------------------ 동작

    private fun launch(app: AppEntry) {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(app.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
            markLaunched(app.pkg)
            closeSearch()
        } catch (e: Exception) {
            Toast.makeText(this, "앱을 열 수 없어요", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openClock() {
        try {
            startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "시계 앱을 열 수 없어요", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCalendar() {
        try {
            startActivity(
                mainSelector(Intent.CATEGORY_APP_CALENDAR).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "캘린더 앱을 열 수 없어요", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showMenu(anchor: View, app: AppEntry) {
        val pinned = pinnedList().contains(app.pkg)
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, if (pinned) "홈 화면에서 제거" else "홈 화면에 추가")
        menu.menu.add(0, 2, 1, "앱 정보")
        menu.menu.add(0, 3, 2, "삭제")
        menu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> {
                    val l = pinnedList()
                    if (pinned) l.remove(app.pkg) else l.add(app.pkg)
                    savePinned(l)
                    buildHome()
                }
                2 -> startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", app.pkg, null))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                3 -> startActivity(
                    Intent(Intent.ACTION_DELETE, Uri.fromParts("package", app.pkg, null))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            true
        }
        menu.show()
    }

    private fun chooseDockApp(slot: Int) {
        if (apps.isEmpty()) return
        val labels = apps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("독에 놓을 앱")
            .setItems(labels) { _, which ->
                val d = dockList()
                d[slot] = apps[which].pkg
                saveDock(d)
                buildDock()
            }
            .show()
    }

    // ------------------------------------------------------------------ 검색

    private fun openSearch() {
        if (searchOverlay != null) return
        val overlay = FrameLayout(this).apply {
            setBackgroundColor(0xF2101018.toInt())
            isClickable = true
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val edit = EditText(this).apply {
            hint = "앱 검색"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 18f
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_GO
            background = roundBg(0x33FFFFFF, dp(14))
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        scroll.addView(results, ViewGroup.LayoutParams(-1, -2))
        box.addView(edit, LinearLayout.LayoutParams(-1, -2))
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(12) })
        overlay.addView(box, FrameLayout.LayoutParams(-1, -1))

        var first: AppEntry? = null
        fun refresh(q: String) {
            results.removeAllViews()
            val hits = apps.filter { q.isBlank() || it.label.contains(q.trim(), ignoreCase = true) }
            first = hits.firstOrNull()
            hits.forEach { app ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(4), dp(8), dp(4), dp(8))
                    setOnClickListener { launch(app) }
                }
                val icon = ImageView(this).apply {
                    setImageBitmap(app.icon)
                    outlineProvider = object : ViewOutlineProvider() {
                        override fun getOutline(view: View, outline: Outline) {
                            outline.setRoundRect(0, 0, view.width, view.height, view.width * 0.225f)
                        }
                    }
                    clipToOutline = true
                }
                row.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))
                row.addView(TextView(this).apply {
                    text = app.label
                    setTextColor(Color.WHITE)
                    textSize = 16f
                    setPadding(dp(14), 0, 0, 0)
                })
                results.addView(row, LinearLayout.LayoutParams(-1, -2))
            }
        }
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                refresh(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        edit.setOnEditorActionListener { _, _, _ ->
            first?.let { launch(it) }
            true
        }

        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        searchOverlay = overlay
        overlayBox = box
        updateOverlayPadding()
        refresh("")
        edit.requestFocus()
        edit.post {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeSearch() {
        val overlay = searchOverlay ?: return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(overlay.windowToken, 0)
        root.removeView(overlay)
        searchOverlay = null
        overlayBox = null
    }

    private fun updateOverlayPadding() {
        overlayBox?.setPadding(
            sidePad(), insetTop + dp(16), sidePad(),
            max(insetBottom, imeBottom) + dp(8)
        )
    }
}
