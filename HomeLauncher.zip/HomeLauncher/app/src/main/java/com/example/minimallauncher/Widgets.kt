package com.example.minimallauncher

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.provider.MediaStore
import android.text.TextPaint
import android.text.TextUtils
import android.util.Size
import android.view.View
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private val main = Handler(Looper.getMainLooper())

private fun granted(ctx: Context, perm: String) =
    ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

/** 아날로그 시계 (직접 그림) */
class ClockWidget(context: Context) : View(context) {
    private val bg = Paint().apply { color = 0xFF1C1C1E.toInt() }
    private val face = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3A3A3C.toInt(); strokeCap = Paint.Cap.ROUND }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF111111.toInt(); textAlign = Paint.Align.CENTER }
    private val hand = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF111111.toInt(); strokeCap = Paint.Cap.ROUND }
    private val sec = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF9F0A.toInt(); strokeCap = Paint.Cap.ROUND }
    private val ticker = object : Runnable {
        override fun run() {
            invalidate()
            postDelayed(this, 1000L - System.currentTimeMillis() % 1000L)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(ticker) }
    override fun onDetachedFromWindow() { removeCallbacks(ticker); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, bg)
        val cx = w / 2; val cy = h / 2
        val r = min(w, h) * 0.43f
        c.drawCircle(cx, cy, r, face)
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0)
            val major = i % 5 == 0
            val len = if (major) r * 0.1f else r * 0.05f
            tick.strokeWidth = if (major) r * 0.03f else r * 0.012f
            c.drawLine(
                cx + (sin(a) * (r * 0.95f - len)).toFloat(), cy - (cos(a) * (r * 0.95f - len)).toFloat(),
                cx + (sin(a) * r * 0.95f).toFloat(), cy - (cos(a) * r * 0.95f).toFloat(), tick
            )
        }
        num.textSize = r * 0.21f
        val off = (num.ascent() + num.descent()) / 2
        for (n in 1..12) {
            val a = Math.toRadians(n * 30.0)
            c.drawText(n.toString(), cx + (sin(a) * r * 0.68f).toFloat(), cy - (cos(a) * r * 0.68f).toFloat() - off, num)
        }
        val cal = Calendar.getInstance()
        val s = cal.get(Calendar.SECOND).toFloat()
        val m = cal.get(Calendar.MINUTE) + s / 60f
        val hr = (cal.get(Calendar.HOUR) % 12) + m / 60f
        fun line(deg: Float, len: Float, wd: Float, p: Paint) {
            val a = Math.toRadians(deg.toDouble())
            p.strokeWidth = wd
            c.drawLine(cx, cy, cx + (sin(a) * len).toFloat(), cy - (cos(a) * len).toFloat(), p)
        }
        line(hr * 30f, r * 0.5f, r * 0.075f, hand)
        line(m * 6f, r * 0.76f, r * 0.055f, hand)
        line(s * 6f, r * 0.84f, r * 0.02f, sec)
        c.drawCircle(cx, cy, r * 0.05f, sec)
    }
}

/** 캘린더 위젯: 요일, 날짜, 오늘 일정 */
class CalendarWidget(context: Context, private val askPermission: () -> Unit) : View(context) {
    private class Ev(val title: String, val color: Int, val time: String)

    private var events: List<Ev> = emptyList()
    private val title = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF3B30.toInt(); typeface = Typeface.DEFAULT_BOLD }
    private val big = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1C1C1E.toInt() }
    private val ev = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1C1C1E.toInt(); typeface = Typeface.DEFAULT_BOLD }
    private val sub = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8E8E93.toInt() }
    private val chip = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        setOnClickListener {
            if (!granted(context, Manifest.permission.READ_CALENDAR)) askPermission()
            else try {
                context.startActivity(
                    Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) { }
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); refresh() }

    fun refresh() {
        if (!granted(context, Manifest.permission.READ_CALENDAR)) { events = emptyList(); invalidate(); return }
        val ctx = context.applicationContext
        Thread {
            val out = ArrayList<Ev>()
            try {
                val start = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
                ContentUris.appendId(b, start)
                ContentUris.appendId(b, start + 24L * 3600 * 1000 - 1)
                ctx.contentResolver.query(
                    b.build(),
                    arrayOf(
                        CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN,
                        CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.DISPLAY_COLOR
                    ),
                    "${CalendarContract.Instances.VISIBLE}=1", null,
                    "${CalendarContract.Instances.ALL_DAY} DESC, ${CalendarContract.Instances.BEGIN} ASC"
                )?.use { cur ->
                    while (cur.moveToNext() && out.size < 3) {
                        val allDay = cur.getInt(2) == 1
                        val t = if (allDay) "" else {
                            val cal = Calendar.getInstance().apply { timeInMillis = cur.getLong(1) }
                            String.format(Locale.KOREA, "%d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
                        }
                        out.add(Ev(cur.getString(0) ?: "", cur.getInt(3), t))
                    }
                }
            } catch (e: Exception) { }
            main.post { events = out; invalidate() }
        }.start()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(Color.WHITE)
        val pad = w * 0.11f
        val cal = Calendar.getInstance()
        val days = arrayOf("일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일")
        title.textSize = h * 0.075f
        var y = pad - title.ascent()
        c.drawText(days[cal.get(Calendar.DAY_OF_WEEK) - 1], pad, y, title)
        big.textSize = h * 0.26f
        y += h * 0.02f - big.ascent() * 0.86f
        c.drawText(cal.get(Calendar.DAY_OF_MONTH).toString(), pad - h * 0.01f, y, big)
        y += h * 0.07f
        val avail = w - pad * 2
        if (!granted(context, Manifest.permission.READ_CALENDAR)) {
            sub.textSize = h * 0.06f
            c.drawText(TextUtils.ellipsize("탭하여 일정 표시", sub, avail, TextUtils.TruncateAt.END).toString(), pad, y - sub.ascent(), sub)
            return
        }
        if (events.isEmpty()) {
            sub.textSize = h * 0.065f
            c.drawText("오늘 일정 없음", pad, y - sub.ascent(), sub)
            return
        }
        ev.textSize = h * 0.062f
        val rowH = h * 0.12f
        for (e in events) {
            if (y + rowH > h - pad * 0.4f) break
            val col = if (e.color == 0) 0xFF5E5CE6.toInt() else (e.color or 0xFF000000.toInt())
            chip.color = (col and 0x00FFFFFF) or 0x26000000
            c.drawRoundRect(RectF(pad - w * 0.03f, y, w - pad + w * 0.03f, y + rowH), rowH * 0.3f, rowH * 0.3f, chip)
            chip.color = col
            c.drawRoundRect(RectF(pad, y + rowH * 0.2f, pad + w * 0.018f, y + rowH * 0.8f), w * 0.01f, w * 0.01f, chip)
            val text = if (e.time.isEmpty()) e.title else "${e.time} ${e.title}"
            c.drawText(
                TextUtils.ellipsize(text, ev, avail - w * 0.05f, TextUtils.TruncateAt.END).toString(),
                pad + w * 0.045f, y + rowH / 2 - (ev.ascent() + ev.descent()) / 2, ev
            )
            y += rowH + h * 0.025f
        }
    }
}

/** 배터리 위젯: 원형 게이지 + 퍼센트 */
class BatteryWidget(context: Context) : View(context) {
    private var level = -1
    private var charging = false
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x33FFFFFF; strokeCap = Paint.Cap.ROUND }
    private val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE }
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { update(i) }
    }

    private fun update(i: Intent?) {
        if (i == null) return
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        level = if (l >= 0 && s > 0) l * 100 / s else -1
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, 0)
        charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val sticky = if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else context.registerReceiver(receiver, f)
        update(sticky)
    }

    override fun onDetachedFromWindow() {
        try { context.unregisterReceiver(receiver) } catch (e: Exception) { }
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(0xFF1C1C1E.toInt())
        val r = min(w, h) * 0.2f
        val cx = w * 0.11f + r + r * 0.15f
        val cy = h * 0.11f + r + r * 0.15f
        val sw = r * 0.26f
        track.strokeWidth = sw
        prog.strokeWidth = sw
        prog.color = when {
            charging -> 0xFF30D158.toInt()
            level in 0..20 -> 0xFFFF453A.toInt()
            else -> 0xFF30D158.toInt()
        }
        val oval = RectF(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(oval, 0f, 360f, false, track)
        if (level >= 0) c.drawArc(oval, -90f, 360f * level / 100f, false, prog)
        // 휴대폰 모양
        glyph.strokeWidth = r * 0.09f
        val pw = r * 0.5f; val ph = r * 0.9f
        c.drawRoundRect(RectF(cx - pw / 2, cy - ph / 2, cx + pw / 2, cy + ph / 2), pw * 0.22f, pw * 0.22f, glyph)
        text.textSize = h * 0.25f
        val s = if (level >= 0) "$level%" else "--"
        c.drawText(s, w * 0.11f, h - h * 0.11f - text.descent(), text)
    }
}

/** 사진 위젯: 갤러리 사진 중 하나를 시간마다 바꿔 보여줌 */
class PhotoWidget(context: Context, private val askPermission: () -> Unit) : View(context) {
    private var bmp: Bitmap? = null
    private var uri: Uri? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val bg = Paint()

    init {
        setOnClickListener {
            val u = uri
            if (!hasPermission()) askPermission()
            else if (u != null) try {
                context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "image/*")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (e: Exception) { }
        }
    }

    fun hasPermission(): Boolean = when {
        Build.VERSION.SDK_INT >= 34 -> granted(context, Manifest.permission.READ_MEDIA_IMAGES) ||
            granted(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 -> granted(context, Manifest.permission.READ_MEDIA_IMAGES)
        else -> granted(context, Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); refresh() }

    fun refresh() {
        if (!hasPermission() || width == 0) { if (!hasPermission()) invalidate(); return }
        val ctx = context.applicationContext
        val w = width; val h = height
        Thread {
            var found: Uri? = null
            var b: Bitmap? = null
            try {
                val ids = ArrayList<Long>()
                ctx.contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID),
                    null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { cur -> while (cur.moveToNext() && ids.size < 300) ids.add(cur.getLong(0)) }
                if (ids.isNotEmpty()) {
                    val hour = System.currentTimeMillis() / 3_600_000L
                    val id = ids[(hour % ids.size).toInt()]
                    found = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    b = ctx.contentResolver.loadThumbnail(found, Size(max(w, 1), max(h, 1)), null)
                }
            } catch (e: Exception) { }
            main.post { uri = found; bmp = b; invalidate() }
        }.start()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bg.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFF5E5CE6.toInt(), 0xFFBF5AF2.toInt(), Shader.TileMode.CLAMP)
        if (bmp == null) refresh()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val b = bmp
        if (b != null) {
            // 가운데 기준으로 꽉 채우기
            val scale = max(w / b.width, h / b.height)
            val sw = w / scale; val sh = h / scale
            val sx = (b.width - sw) / 2f; val sy = (b.height - sh) / 2f
            c.drawBitmap(b, Rect(sx.toInt(), sy.toInt(), (sx + sw).toInt(), (sy + sh).toInt()), RectF(0f, 0f, w, h), paint)
            return
        }
        c.drawRect(0f, 0f, w, h, bg)
        text.textSize = h * 0.09f
        text.typeface = Typeface.DEFAULT_BOLD
        c.drawText("사진", w * 0.07f, h - h * 0.2f, text)
        text.textSize = h * 0.06f
        text.typeface = Typeface.DEFAULT
        val msg = if (hasPermission()) "표시할 사진이 없음" else "탭하여 사진 접근 허용"
        c.drawText(msg, w * 0.07f, h - h * 0.09f, text)
    }
}
