package com.example.minimallauncher

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RectF
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.hypot
import kotlin.math.max
import kotlin.random.Random

/** 아이콘 + 이름 + 배지 + 파란 점 + 편집 모드 − 버튼을 한 뷰에서 그린다 */
class IconView(context: Context, private val host: Host) : View(context) {

    interface Host {
        fun isEditMode(): Boolean
        fun onIconClick(v: IconView)
        fun onIconLongPress(v: IconView, rawX: Float, rawY: Float)
        fun onIconDragMove(v: IconView, rawX: Float, rawY: Float)
        fun onIconDragEnd(v: IconView, rawX: Float, rawY: Float, cancelled: Boolean)
        fun onIconMinus(v: IconView)
    }

    var item: HomeItem? = null
    var app: AppInfo? = null
    var payload: Any? = null
    var lastParent: Any? = null

    var bitmap: Bitmap? = null
        set(v) { field = v; invalidate() }
    var label: String = ""
        set(v) { field = v; invalidate() }
    var showLabel = true
    var badge = 0
        set(v) { field = v; invalidate() }
    var dot = false
        set(v) { field = v; invalidate() }
    var showMinus = false
        set(v) { field = v; invalidate() }
    var highlight = false
        set(v) { if (field != v) { field = v; invalidate() } }
    var iconSize = 100
    var labelPx = 30f
    var labelColor = Color.WHITE

    private val density = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dimFilter = PorterDuffColorFilter(0x66000000, PorterDuff.Mode.SRC_ATOP)
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF0A84FF.toInt() }
    private val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF3B30.toInt() }
    private val badgeText = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val minusBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6D1D1D6.toInt() }
    private val minusFg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF1C1C1E.toInt()
        strokeCap = Paint.Cap.ROUND
    }
    private val hiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x59FFFFFF }

    private var pressedDim = false
    private var downX = 0f
    private var downY = 0f
    private var longFired = false
    private var editDrag = false
    private var dragging = false
    private var minusDown = false
    private var jiggle: ObjectAnimator? = null

    private val longPress = Runnable {
        longFired = true
        pressedDim = false
        invalidate()
        parent?.requestDisallowInterceptTouchEvent(true)
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        host.onIconLongPress(this, downX, downY)
    }

    fun iconLeft(): Float = (width - iconSize) / 2f

    fun iconTop(): Float {
        if (!showLabel) return (height - iconSize) / 2f
        val block = iconSize + labelPx * 0.45f + labelPx * 1.25f
        return max(0f, (height - block) / 2f)
    }

    /** 화면 좌표 기준 아이콘 사각형 */
    fun iconRectOnScreen(): RectF {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val l = loc[0] + iconLeft()
        val t = loc[1] + iconTop()
        return RectF(l, t, l + iconSize, t + iconSize)
    }

    fun setJiggle(on: Boolean) {
        if (on) {
            if (jiggle != null) return
            pivotX = width / 2f
            pivotY = iconTop() + iconSize / 2f
            val a = ObjectAnimator.ofFloat(this, "rotation", -1.6f, 1.6f)
            a.duration = 120L + Random.nextLong(30)
            a.repeatCount = ValueAnimator.INFINITE
            a.repeatMode = ValueAnimator.REVERSE
            a.startDelay = Random.nextLong(100)
            a.start()
            jiggle = a
        } else {
            jiggle?.cancel()
            jiggle = null
            rotation = 0f
        }
    }

    override fun onDetachedFromWindow() {
        jiggle?.cancel()
        jiggle = null
        super.onDetachedFromWindow()
    }

    private fun minusCenterX() = iconLeft() + iconSize * 0.06f
    private fun minusCenterY() = iconTop() + iconSize * 0.06f
    private fun minusR() = iconSize * 0.19f

    private fun hitMinus(x: Float, y: Float): Boolean =
        hypot(x - minusCenterX(), y - minusCenterY()) < minusR() * 1.6f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                longFired = false; dragging = false; minusDown = false
                editDrag = host.isEditMode()
                if (showMinus && hitMinus(e.x, e.y)) {
                    minusDown = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                if (editDrag) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                } else {
                    pressedDim = true
                    invalidate()
                    postDelayed(longPress, LONG_PRESS_MS)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (minusDown) return true
                val dist = hypot(e.rawX - downX, e.rawY - downY)
                if (dragging) {
                    host.onIconDragMove(this, e.rawX, e.rawY)
                } else if ((longFired || editDrag) && dist > slop) {
                    dragging = true
                    host.onIconDragMove(this, e.rawX, e.rawY)
                } else if (!longFired && !editDrag && dist > slop) {
                    removeCallbacks(longPress)
                    if (pressedDim) { pressedDim = false; invalidate() }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                if (pressedDim) { pressedDim = false; invalidate() }
                val dist = hypot(e.rawX - downX, e.rawY - downY)
                when {
                    minusDown -> if (hitMinus(e.x, e.y)) host.onIconMinus(this)
                    dragging || longFired -> host.onIconDragEnd(this, e.rawX, e.rawY, false)
                    dist <= slop -> host.onIconClick(this)
                }
                longFired = false; dragging = false; minusDown = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                if (pressedDim) { pressedDim = false; invalidate() }
                if (dragging || longFired) host.onIconDragEnd(this, e.rawX, e.rawY, true)
                longFired = false; dragging = false; minusDown = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val b = bitmap ?: return
        val l = iconLeft()
        val t = iconTop()
        val rect = RectF(l, t, l + iconSize, t + iconSize)
        if (highlight) {
            val grow = iconSize * 0.12f
            c.drawPath(IconFactory.squircle(l - grow, t - grow, iconSize + grow * 2), hiPaint)
        }
        bmpPaint.colorFilter = if (pressedDim) dimFilter else null
        c.drawBitmap(b, null, rect, bmpPaint)

        if (showLabel && label.isNotEmpty()) {
            textPaint.textSize = labelPx
            textPaint.color = labelColor
            textPaint.setShadowLayer(labelPx * 0.18f, 0f, labelPx * 0.04f, 0x80000000.toInt())
            val dotD = if (dot) labelPx * 0.42f else 0f
            val dotGap = if (dot) labelPx * 0.25f else 0f
            val maxW = width - 4 * density - dotD - dotGap
            val text = TextUtils.ellipsize(label, textPaint, maxW, TextUtils.TruncateAt.END).toString()
            val tw = textPaint.measureText(text)
            val total = dotD + dotGap + tw
            val startX = (width - total) / 2f
            val baseY = t + iconSize + labelPx * 0.45f - textPaint.ascent()
            if (dot) {
                val cy = baseY + (textPaint.ascent() + textPaint.descent()) / 2f
                c.drawCircle(startX + dotD / 2f, cy, dotD / 2f, dotPaint)
            }
            c.drawText(text, startX + dotD + dotGap, baseY, textPaint)
        }

        if (badge > 0) {
            val h = iconSize * 0.36f
            badgeText.textSize = iconSize * 0.24f
            val txt = badge.toString()
            val w = max(h, badgeText.measureText(txt) + h * 0.55f)
            val cx = l + iconSize - iconSize * 0.06f
            val cy = t + iconSize * 0.06f
            val r = RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
            c.drawRoundRect(r, h / 2f, h / 2f, badgePaint)
            c.drawText(txt, cx, cy - (badgeText.ascent() + badgeText.descent()) / 2f, badgeText)
        }

        if (showMinus) {
            val cx = minusCenterX()
            val cy = minusCenterY()
            val r = minusR()
            c.drawCircle(cx, cy, r, minusBg)
            minusFg.strokeWidth = r * 0.22f
            c.drawLine(cx - r * 0.45f, cy, cx + r * 0.45f, cy, minusFg)
        }
    }

    companion object {
        const val LONG_PRESS_MS = 450L
    }
}
