package com.example.minimallauncher

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** 알림 개수 → 앱 아이콘 빨간 배지. '알림 접근' 권한이 있어야 동작 */
class BadgeService : NotificationListenerService() {
    override fun onListenerConnected() { recount() }
    override fun onListenerDisconnected() { Badges.update(emptyMap()) }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { recount() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { recount() }

    private fun recount() {
        val m = HashMap<String, Int>()
        try {
            activeNotifications?.forEach { sbn ->
                val n = sbn.notification
                if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return@forEach
                if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return@forEach
                if (n.flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return@forEach
                val add = if (n.number > 0) n.number else 1
                m[sbn.packageName] = (m[sbn.packageName] ?: 0) + add
            }
        } catch (e: Exception) { }
        Badges.update(m)
    }
}

object Badges {
    @Volatile var counts: Map<String, Int> = emptyMap()
        private set
    var listener: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    fun update(m: Map<String, Int>) {
        main.post {
            if (m != counts) {
                counts = m
                listener?.invoke()
            }
        }
    }
}
