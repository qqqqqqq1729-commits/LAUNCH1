package com.example.minimallauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.widget.HorizontalScrollView
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** 아날로그 시계 위젯 (직접 그린 것. 애플 위젯 이미지는 쓰지 않음) */
class ClockView(context: Context) : View(context) {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val face = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF222222.toInt()
        strokeCap = Paint.Cap.ROUND
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF111111.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    }
    private val hand = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF111111.toInt()
        strokeCap = Paint.Cap.ROUND
    }
    private val secondHand = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF9500.toInt()
        strokeCap = Paint.Cap.ROUND
    }

    private val ticker = object : Runnable {
        override fun run() {
            invalidate()
            postDelayed(this, 1000L - System.currentTimeMillis() % 1000L)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bg.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            0xFF50578C.toInt(), 0xFF2B2F55.toInt(), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRoundRect(0f, 0f, w, h, w * 0.2f, w * 0.2f, bg)

        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) * 0.41f
        c.drawCircle(cx, cy, r, face)

        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0)
            val major = i % 5 == 0
            val len = if (major) r * 0.09f else r * 0.045f
            tick.strokeWidth = if (major) r * 0.03f else r * 0.015f
            val x1 = cx + (sin(a) * (r - len)).toFloat()
            val y1 = cy - (cos(a) * (r - len)).toFloat()
            val x2 = cx + (sin(a) * (r - r * 0.02f)).toFloat()
            val y2 = cy - (cos(a) * (r - r * 0.02f)).toFloat()
            c.drawLine(x1, y1, x2, y2, tick)
        }

        num.textSize = r * 0.2f
        val offset = (num.ascent() + num.descent()) / 2f
        for (n in 1..12) {
            val a = Math.toRadians(n * 30.0)
            val rr = r * 0.7f
            val x = cx + (sin(a) * rr).toFloat()
            val y = cy - (cos(a) * rr).toFloat() - offset
            c.drawText(n.toString(), x, y, num)
        }

        val cal = Calendar.getInstance()
        val sec = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f
        val minutes = cal.get(Calendar.MINUTE) + sec / 60f
        val hours = (cal.get(Calendar.HOUR) % 12) + minutes / 60f

        drawHand(c, cx, cy, hours * 30f, r * 0.5f, r * 0.07f, hand)
        drawHand(c, cx, cy, minutes * 6f, r * 0.75f, r * 0.05f, hand)
        drawHand(c, cx, cy, sec * 6f, r * 0.82f, r * 0.02f, secondHand)
        c.drawCircle(cx, cy, r * 0.045f, secondHand)
    }

    private fun drawHand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, width: Float, p: Paint) {
        val a = Math.toRadians(deg.toDouble())
        p.strokeWidth = width
        c.drawLine(cx, cy, cx + (sin(a) * len).toFloat(), cy - (cos(a) * len).toFloat(), p)
    }
}

/** 월간 캘린더 위젯 (월요일 시작, 오늘은 빨간 원) */
class CalendarView(context: Context) : View(context) {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1C1C1E.toInt() }
    private val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFF453A.toInt()
        typeface = Typeface.DEFAULT_BOLD
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val day = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }
    private val todayBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF453A.toInt() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRoundRect(0f, 0f, w, h, w * 0.2f, w * 0.2f, bg)

        val now = Calendar.getInstance()
        val today = now.get(Calendar.DAY_OF_MONTH)
        val first = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
        // 월요일 시작: 일(1)~토(7) -> 월(0)~일(6)
        val startOffset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val daysInMonth = now.getActualMaximum(Calendar.DAY_OF_MONTH)

        val padX = w * 0.08f
        val cellW = (w - padX * 2) / 7f
        val rows = 8f // 제목 1 + 요일 1 + 날짜 최대 6
        val cellH = (h - w * 0.06f) / rows

        title.textSize = cellH * 0.62f
        c.drawText("${now.get(Calendar.MONTH) + 1}월", padX, w * 0.03f + cellH * 0.85f, title)

        head.textSize = cellH * 0.5f
        day.textSize = cellH * 0.55f
        val headY = w * 0.03f + cellH * 1.85f
        val names = arrayOf("M", "T", "W", "T", "F", "S", "S")
        for (i in 0 until 7) {
            head.color = if (i >= 5) 0xFF8E8E93.toInt() else Color.WHITE
            c.drawText(names[i], padX + cellW * (i + 0.5f), headY, head)
        }

        val textOffset = (day.ascent() + day.descent()) / 2f
        for (d in 1..daysInMonth) {
            val idx = startOffset + d - 1
            val col = idx % 7
            val row = idx / 7
            val cx = padX + cellW * (col + 0.5f)
            val cy = w * 0.03f + cellH * (2.5f + row + 0.5f) + cellH * 0.1f
            if (d == today) {
                c.drawCircle(cx, cy, cellH * 0.45f, todayBg)
            }
            day.color = when {
                d == today -> Color.WHITE
                col >= 5 -> 0xFF8E8E93.toInt()
                else -> Color.WHITE
            }
            c.drawText(d.toString(), cx, cy - textOffset, day)
        }
    }
}

/** 가로 2페이지(홈 / 앱 보관함) 스냅 스크롤 */
class Pager(context: Context) : HorizontalScrollView(context) {
    var pageWidth = 0
    var page = 0
        private set
    private var downX = 0f
    private var startPage = 0

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        isFillViewport = true
    }

    fun goTo(p: Int, animate: Boolean = true) {
        page = p.coerceIn(0, 1)
        if (animate) smoothScrollTo(page * pageWidth, 0) else scrollTo(page * pageWidth, 0)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            downX = ev.x
            startPage = page
        }
        return super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            downX = ev.x
            startPage = page
        }
        val handled = super.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
            val dx = ev.x - downX
            val threshold = pageWidth * 0.15f
            val target = when {
                dx < -threshold -> startPage + 1
                dx > threshold -> startPage - 1
                else -> startPage
            }
            goTo(target)
            return true
        }
        return handled
    }
}
