plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.minimallauncher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.minimallauncher"
        minSdk = 30
        targetSdk = 35
        versionCode = 3
        versionName = "0.3"
    }

    // 빌드할 때마다 서명 키가 바뀌면 업데이트 설치가 안 되므로 고정 키를 사용
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
